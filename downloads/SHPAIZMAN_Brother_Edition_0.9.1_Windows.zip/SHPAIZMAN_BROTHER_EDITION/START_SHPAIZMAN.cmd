@echo off
setlocal
cd /d "%~dp0"
py -3.12 run.py desktop
set "rc=%errorlevel%"
if %rc% neq 0 pause
exit /b %rc%
