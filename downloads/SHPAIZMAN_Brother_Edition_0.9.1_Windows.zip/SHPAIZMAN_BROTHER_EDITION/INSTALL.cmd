@echo off
setlocal
cd /d "%~dp0"
py -3.12 scripts\install.py
set "rc=%errorlevel%"
pause
exit /b %rc%
