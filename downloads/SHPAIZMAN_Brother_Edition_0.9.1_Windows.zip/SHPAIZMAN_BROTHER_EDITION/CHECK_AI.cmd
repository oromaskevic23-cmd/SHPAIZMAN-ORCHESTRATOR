@echo off
setlocal
cd /d "%~dp0"
py -3.12 -m shpaizman.acceptance %*
set "rc=%errorlevel%"
pause
exit /b %rc%
