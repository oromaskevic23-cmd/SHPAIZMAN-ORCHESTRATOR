@echo off
setlocal
cd /d "%~dp0"
py -3.12 run.py self-test
set "rc=%errorlevel%"
pause
exit /b %rc%
