# Контракты десяти агентов

Локальные операции выполняются настоящим алгоритмом. Они не отправляют данные на платформы и не означают наличие AI inference. Внешние операции выполняет отдельный адаптер после разрешения.

## AGENT-01 — Integration Engineer / albato

Локальная операция: `map_fields`. Пример входного JSON:

```json
{
  "source": {
    "customer": "Example"
  },
  "mapping": {
    "NAME": "customer"
  }
}
```

Внешние операции: list_partners.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-02 — Conversational AI Engineer / aimylogic

Локальная операция: `validate_dialogue`. Пример входного JSON:

```json
{
  "start": "hello",
  "states": [
    {
      "id": "hello",
      "reply": "Hello",
      "next": [
        "end"
      ]
    },
    {
      "id": "end",
      "reply": "Bye",
      "next": []
    }
  ]
}
```

Внешние операции: chat_test.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-03 — Voice Automation Engineer / tomoru

Локальная операция: `validate_voice_script`. Пример входного JSON:

```json
{
  "steps": [
    {
      "id": "welcome",
      "say": "Добрый день",
      "listen_seconds": 5
    }
  ],
  "max_seconds": 60
}
```

Внешние операции: BLOCKED — TOMORU: official authenticated API schema and zero-cost account entitlement not verified; obtain provider documentation.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-04 — Communications Engineer / twin

Локальная операция: `plan_delivery`. Пример входного JSON:

```json
{
  "message": "Example",
  "channels": [
    "CHAT",
    "EMAIL"
  ],
  "available": [
    "EMAIL"
  ]
}
```

Внешние операции: list_messages.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-05 — Language AI Engineer / gigachat

Локальная операция: `prepare_language_batch`. Пример входного JSON:

```json
{
  "texts": [
    "Hello   world",
    "Hello world"
  ]
}
```

Внешние операции: list_models.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-06 — AI Model Engineer / yandex

Локальная операция: `build_model_request`. Пример входного JSON:

```json
{
  "folder_id": "example-folder",
  "model": "yandexgpt-lite",
  "text": "Example",
  "max_tokens": 128
}
```

Внешние операции: list_assistants.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-07 — Workflow Engineer / nodul

Локальная операция: `validate_workflow`. Пример входного JSON:

```json
{
  "nodes": [
    "input",
    "transform",
    "response"
  ],
  "edges": [
    [
      "input",
      "transform"
    ],
    [
      "transform",
      "response"
    ]
  ]
}
```

Внешние операции: run_workflow.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-08 — CRM Automation Engineer / bitrix24

Локальная операция: `normalize_leads`. Пример входного JSON:

```json
{
  "leads": [
    {
      "name": "Example",
      "email": "TEST@example.invalid"
    }
  ]
}
```

Внешние операции: read_profile, list_leads.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-09 — Enterprise AI Engineer / mws

Локальная операция: `validate_agent_policy`. Пример входного JSON:

```json
{
  "name": "Knowledge helper",
  "capabilities": [
    "knowledge.read",
    "draft.create"
  ],
  "approval_required": true
}
```

Внешние операции: BLOCKED — MWS AI Agents: installation-specific API, license and free entitlement are unverified; GPT Model Hub is a different product and is not substituted.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.

## AGENT-10 — Cloud AI Engineer / cloudru

Локальная операция: `filter_zero_cost_models`. Пример входного JSON:

```json
{
  "catalog": [
    {
      "id": "example-free",
      "input_rub_per_million": "0",
      "output_rub_per_million": "0"
    },
    {
      "id": "example-paid",
      "input_rub_per_million": "1",
      "output_rub_per_million": "2"
    }
  ]
}
```

Внешние операции: list_models.

Выход: agent_id, platform, operation, mode=LOCAL_ALGORITHM, external_effects=false, input_sha256, data; после исполнения — worker_metrics и elapsed_ms. Ошибка входа не является успехом. START/STOP AGENT управляют выдачей задач этому исполнителю.
