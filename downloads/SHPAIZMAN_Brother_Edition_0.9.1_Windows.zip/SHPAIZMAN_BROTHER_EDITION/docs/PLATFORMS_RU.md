# Десять площадок: точная граница подключения

Дата проверки документов: 21.10.2026. Реально подтверждённых подключений при подготовке исходного комплекта: **0/10**. Учётные данные не предоставлены. FREE_ONLY разрешается для конкретного аккаунта, метода и срока, а не по рекламе бесплатного тарифа. Локальное заявление владельца не проверяет биллинг провайдера автоматически.

| Агент / площадка | Настройки | Реализованный интернет-метод | Что ещё требуется |
|---|---|---|---|
| 01 Albato | bearer Token | GET `uapi.albato.com/partners/info`, `list_partners` | Собственный master/API-доступ, права и подтверждение бесплатности; схема ответа пока проверена синтетически |
| 02 Aimylogic | Token канала Chat API, изолированный тестовый бот | POST `bot.jaicp.com/chatapi/{token}`, `chat_test` | Опубликованный канал; сценарий без звонков, покупок и сторонних действий; бесплатная квота |
| 03 Tomoru | Не вводить секрет до согласования API | **BLOCKED**, внешние операции не реализованы | Официальная схема аутентифицированного API, разрешение на нужный метод и бесплатный доступ; нужна дальнейшая разработка адаптера |
| 04 TWIN | bearer Token | GET `notify.twin24.ai/api/v1/messages?limit=10`, `list_messages` | Права чтения собственных сообщений и нулевая цена запроса; отправка сообщений/звонков не реализована |
| 05 GigaChat Business | действующий Access token | GET `api.giga.chat/v1/models`, `list_models` | Право бизнес-аккаунта и бесплатный метод; генерация и автоматическое обновление OAuth не реализованы |
| 06 Яндекс AI Studio | API-key в Token, Folder ID | GET `rest-assistant.api.cloud.yandex.net/assistants/v1/assistants`, `list_assistants` | Права каталога и бесплатность; API Assistants требует проверки доступности при переходах платформы; не оплачивать inference |
| 07 Nodul | полный Webhook URL на поддомене nodul.ru; изолированный бесплатный сценарий | POST `run_workflow` с корреляцией ответа | Собственный сценарий и последний узел Webhook Response; другой домен требует проверки и изменения allowlist разработчиком |
| 08 Битрикс24 | Webhook URL `https://<portal>.bitrix24.ru/rest/<user>/<key>/` либо `.com` | `read_profile`, `list_leads` (первая страница, только ID/статус) | Собственный входящий webhook, права, доступ REST в тарифе; никаких гарантий бесплатности тарифа |
| 09 MWS AI Agents | Не вводить секрет до согласования API | **BLOCKED**, внешние операции не реализованы | Документация API конкретной установки, лицензия/разрешение и нулевая стоимость; Model Hub не является заменой AI Agents |
| 10 Cloud.ru AI Factory | bearer Token Foundation Models | GET `foundation-models.api.cloud.ru/v1/models`, `list_models` | Права своего аккаунта, подтверждение бесплатности чтения каталога; платная генерация отсутствует |

Все методы ограничены allowlist, проверкой TLS, размером ответа и тайм-аутом. Нет общего «вызвать любой URL». TLS-ошибки не обходятся; устанавливать сертификаты автоматически программа не будет. При смене API полученный ответ может не соответствовать контракту: задача завершается ERROR/FAILED, а не выдуманным успехом.

## Nodul: подтверждать завершение, а не HTTP 200

Сценарий получает JSON `{"request_id":"<nonce>","input":{...}}`. Последний Response-узел обязан вернуть JSON `{"request_id":"тот же nonce","status":"completed","result":{...}}`. Быстрый ответ Webhook 200 без этой структуры не означает выполненную работу. Сценарий должен содержать только разрешённые бесплатные действия; платные AI-узлы, рассылки и внешние побочные действия в тестовом сценарии запрещены. Автоматический повтор POST отключён.

## Порядок проверки каждой доступной площадки

1. Владелец проверяет условия API и выключает списания/платное превышение квоты в аккаунте. Если интерфейс не позволяет гарантировать ограничение бюджета, подключение остаётся BLOCKED.
2. В SETTINGS указывает секрет, источник доказательства бесплатности и подтверждение. Не путать trial с бессрочным бесплатным доступом.
3. Создаёт задачу допустимого метода, проверяет точные данные и локально одобряет её.
4. Запускает очередь. VIEW RESULT должен содержать `mode: REMOTE`, `transport: REAL_HTTPS`, код 200, хеш ответа и время проверки, а также валидный результат метода.
5. Записывает подтверждение в акт. Если ответа нет — NOT_CONNECTED/ERROR/BLOCKED, не PASS. Отмена не отзывает уже отправленное действие у провайдера.

## Официальные источники

- Albato: https://docs.albato.com/docs/general-information и https://docs.albato.com/reference/get_partners-info
- Aimylogic Chat API: https://help.cloud.just-ai.com/aimylogic/publication_channels/chat_api/
- TOMORU: https://tomoru.ru/price ; https://api.tomoru.ru/openapi не удалось прочитать при подготовке. Догадок о контракте нет.
- TWIN: https://developers.twin24.ai/reference/messagelist
- GigaChat: https://developers.sber.ru/docs/ru/gigachat/api/reference/rest/get-models
- Яндекс: https://yandex.cloud/ru/docs/ai-studio/assistants/api-ref/Assistant/list
- Nodul: https://documentation.nodul.ru/integrations/core-nodes/trigger-on-webhook и https://documentation.nodul.ru/integrations/core-nodes/webhook-response
- Битрикс24: https://apidocs.bitrix24.com/local-integrations/local-webhooks.html
- MWS AI Agents: https://mts.ai/product/ai-agents-platform/
- Cloud.ru: https://cloud.ru/docs/foundation-models/ug/topics/api-ref__specs
- Telegram Bot API: https://core.telegram.org/bots/api

Синтетические протокольные тесты в `tests/test_connector_contracts.py` не проверяют текущий сервер, лицензию, тариф или аккаунт. Для TOMORU и MWS недостаточно просто вставить токен: эти два адаптера должны быть реализованы после получения документации.
