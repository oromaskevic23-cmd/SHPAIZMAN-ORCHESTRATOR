$ErrorActionPreference = 'Stop'
Write-Host 'SHPAIZMAN read-only Windows preflight'
Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,OSArchitecture,FreePhysicalMemory,TotalVisibleMemorySize
Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors
Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,DriverDate
Get-PSDrive C | Select-Object Name,Used,Free
& py -3 --version
if ($LASTEXITCODE -ne 0) { throw 'Python missing. Install official Python 3.12 x64 with Tcl/Tk.' }
& py -3 -c 'import sys,struct,sqlite3,tkinter; print(sys.version,struct.calcsize(chr(80))*8,sqlite3.sqlite_version,tkinter.TkVersion)'
if ($LASTEXITCODE -ne 0) { throw 'Python/Tk/SQLite check failed' }
Write-Host 'No BIOS, driver, firewall, virtualization or security settings changed.'
