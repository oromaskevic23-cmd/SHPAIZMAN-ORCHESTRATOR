"""Measured bounded local workload, never a target hardware or external API claim."""
from pathlib import Path
import argparse
import json
import multiprocessing
import os
import platform
import sys
import tempfile
import time

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shpaizman.orchestrator import Orchestrator
from shpaizman.resources import process_metrics


def run():
    with tempfile.TemporaryDirectory(prefix="shpaizman-perf-") as folder:
        app = Orchestrator(Path(folder))
        try:
            jobs = [app.submit(a.platform, a.operation, a.example) for _ in range(3) for a in app.agents.values()]
            start = time.monotonic()
            cpu_start = process_metrics()["cpu_seconds"]
            peak_rss, peak_workers, measured, samples = 0, 0, 0, 0
            app.start()
            while time.monotonic()-start < 120:
                with app.guard:
                    pids = [a[0].pid for a in app.active.values()]
                    snap = app.resources.snapshot(pids)
                samples += 1
                if snap["all_processes_measured"]:
                    measured += 1
                    peak_rss = max(peak_rss, snap["rss_bytes"])
                peak_workers = max(peak_workers, len(pids))
                states = [app.store.task(j)["state"] for j in jobs]
                if all(s == "SUCCEEDED_LOCAL" for s in states):
                    break
                if any(s in {"FAILED", "BLOCKED", "TIMED_OUT"} for s in states):
                    raise RuntimeError("Local workload failed")
                time.sleep(0.02)
            else:
                raise RuntimeError("Performance run timed out: " + app.reason)
            elapsed = time.monotonic()-start
            child_cpu = sum(json.loads(app.store.task(j)["result"])["worker_metrics"]["cpu_seconds"] or 0 for j in jobs)
            parent_cpu = process_metrics()["cpu_seconds"]-cpu_start
            return {"status": "PASS" if measured >= samples//2 else "BLOCKED", "environment": platform.platform(), "python": platform.python_version(),
                    "scope": "30 small local example tasks; no network, AI model or target-PC benchmark",
                    "tasks_succeeded": len(jobs), "elapsed_seconds": round(elapsed, 3),
                    "sample_interval_ms": 20, "samples": samples, "complete_process_samples": measured,
                    "sampled_peak_parent_and_workers_rss_bytes": peak_rss, "observed_max_workers": peak_workers,
                    "parent_cpu_seconds": round(parent_cpu, 3), "workers_cpu_seconds_to_result": round(child_cpu, 3),
                    "average_cpu_percent_one_core": round(100*(parent_cpu+child_cpu)/elapsed, 2),
                    "gpu_measurement": "BLOCKED: no target NVIDIA device; core uses no GPU API",
                    "limitations": "Sampling can miss short peaks; worker CPU excludes final exit cleanup. No long-duration or live-integration stability claim."}
        finally:
            app.close()


if __name__ == "__main__":
    multiprocessing.freeze_support()
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    result = run()
    encoded = json.dumps(result, ensure_ascii=False, indent=2)
    if a.output:
        a.output.parent.mkdir(parents=True, exist_ok=True)
        a.output.write_text(encoded, encoding="utf-8")
    print(encoded)
