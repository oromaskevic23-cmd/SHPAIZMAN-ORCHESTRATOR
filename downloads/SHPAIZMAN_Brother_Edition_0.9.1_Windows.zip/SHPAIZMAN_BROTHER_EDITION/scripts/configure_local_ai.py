"""Explicit local opt-in; never downloads a model or starts an executable."""
import hashlib
from pathlib import Path
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from shpaizman.legacy import default_db_path
from shpaizman.security import Vault


def main():
    root = tk.Tk()
    root.withdraw()
    try:
        file = filedialog.askopenfilename(title="Выберите уже установленную GGUF-модель", filetypes=[("GGUF", "*.gguf")])
        if not file:
            return
        model = simpledialog.askstring("LOCAL_AI", "Точный ID модели на локальном сервере 127.0.0.1:8081")
        if not model or not messagebox.askyesno("Лицензия", "Вы проверили источник модели и лицензию, включая коммерческое использование? Сервер установлен отдельно и работает только на loopback?"):
            return
        with Path(file).open("rb") as f:
            digest = hashlib.file_digest(f, "sha256").hexdigest()
        Vault(default_db_path().parent).save("local_ai", {"enabled": True, "license_reviewed": True,
                                                         "model": model, "model_sha256": digest})
        messagebox.showinfo("LOCAL_AI", "Конфигурация benchmark сохранена. Сервер и модель не запущены. Выполните run.py local-ai-benchmark отдельно.")
    except Exception as error:
        messagebox.showerror("LOCAL_AI", type(error).__name__ + ": настройка не выполнена")
    finally:
        root.destroy()


if __name__ == "__main__":
    main()
