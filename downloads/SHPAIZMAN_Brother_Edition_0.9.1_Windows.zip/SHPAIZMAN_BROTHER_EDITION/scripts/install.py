"""Per-user offline Python installation; no pip, cloud, services or admin rights."""
from pathlib import Path
import argparse
import json
import os
import shutil
import struct
import sys

from verify_manifest import verify


def install(source, destination):
    if os.name != "nt" or struct.calcsize("P") != 8 or sys.getwindowsversion().major < 10:
        raise RuntimeError("Installer requires Windows 10/11 x64")
    if not (3, 11) <= sys.version_info[:2] <= (3, 14):
        raise RuntimeError("Install Python 3.12 x64 with Tcl/Tk (supported: 3.11..3.14)")
    import tkinter
    root = tkinter.Tk()
    root.withdraw()
    root.update()
    root.destroy()
    count = verify(source)
    destination = destination.resolve()
    if destination == source.resolve() or source.resolve().is_relative_to(destination):
        raise RuntimeError("Choose a separate installation directory")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(destination.parent).free < 512*1024**2:
        raise RuntimeError("Need at least 512 MiB free disk space")
    # Never overwrite an installed directory or user's data.
    if destination.exists():
        raise RuntimeError("Destination already exists; choose a new version folder")
    staging = destination.with_name(destination.name + ".installing")
    if staging.exists():
        raise RuntimeError("Previous interrupted installation exists; inspect it before retrying")
    staging.mkdir()
    try:
        lines = (source / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
        for line in lines:
            relative = line.split("  ", 1)[1]
            target = staging / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source / relative, target)
        shutil.copy2(source/"SHA256SUMS.txt", staging/"SHA256SUMS.txt")
        verify(staging)
        staging.rename(destination)
    except BaseException:
        shutil.rmtree(staging)
        raise
    return {"status": "PASS", "installed_path": str(destination), "verified_files": count,
            "python": sys.version, "launch": str(destination / "START_SHPAIZMAN.cmd"),
            "note": "Installation test only; target-PC and account acceptance are separate"}


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--destination", type=Path, default=Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "SHPAIZMAN-BROTHER-EDITION" / "app-0.9.1")
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    result = install(Path(__file__).resolve().parent.parent, a.destination)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if a.output:
        a.output.parent.mkdir(parents=True, exist_ok=True)
        a.output.write_text(text, encoding="utf-8")
    print(text)
