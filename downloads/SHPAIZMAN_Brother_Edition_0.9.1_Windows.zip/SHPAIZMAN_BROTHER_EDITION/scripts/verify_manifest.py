from pathlib import Path, PurePosixPath
import hashlib
import sys


def verify(root):
    root = Path(root).resolve()
    manifest = root / "SHA256SUMS.txt"
    if not manifest.is_file():
        raise ValueError("SHA256SUMS.txt missing")
    count = 0
    seen = set()
    for line in manifest.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        p = PurePosixPath(relative)
        if p.is_absolute() or ".." in p.parts or "\\" in relative or ":" in relative or relative in seen:
            raise ValueError("Unsafe or duplicate manifest path")
        seen.add(relative)
        file = root / relative
        if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(root):
            raise ValueError("Missing or unsafe file: " + relative)
        if hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise ValueError("SHA-256 mismatch: " + relative)
        count += 1
    # Unlisted executables may alter import behavior or installer execution.
    for file in root.rglob("*"):
        rel = file.relative_to(root)
        if any(p in {".git", "__pycache__", ".venv", "dist", "build", "artifacts"} for p in rel.parts):
            continue
        if file.suffix.lower() in {".py", ".pyw", ".exe", ".dll", ".pyd", ".cmd", ".bat", ".ps1"} and rel.as_posix() not in seen:
            raise ValueError("Unlisted executable file: " + rel.as_posix())
    if count == 0:
        raise ValueError("Empty manifest")
    return count


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
    print("SHA256 PASS:", verify(target), "files")
