"""Read-only machine-readable handover for a separately authorized brother Astra."""
from pathlib import Path
import argparse
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from shpaizman.handover import write_handover

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('SHPAIZMAN_ASTRA_HANDOVER.json'))
    opts=parser.parse_args()
    result=write_handover(Path(__file__).resolve().parent.parent,opts.output)
    print(json.dumps(result,indent=2))
