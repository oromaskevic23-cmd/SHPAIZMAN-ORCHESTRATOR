"""Service Factory tests: safe customer lifecycle and no invented payment."""
import hashlib
from pathlib import Path
from contextlib import closing
import sqlite3
import tempfile
import unittest

from shpaizman.business import BusinessDenied, ServiceFactory, SERVICES, STAGES

H=lambda x:hashlib.sha256(x.encode()).hexdigest()
KEY=lambda i:f"business_event_key_{i:03d}"

class BusinessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.biz=ServiceFactory(Path(self.temp.name))
        self.i=0

    def lead(self, **kwargs):
        data=dict(customer_alias="Example Customer",client_reference="CONSENT-001",
                  service="crm_pipeline",quote_minor=50000,currency="RUB",
                  event_key=KEY(0),contact_consent=True)
        data.update(kwargs)
        return self.biz.create_lead(**data)

    def step(self, order_id, stage, **kw):
        self.i+=1
        data=dict(event_key=KEY(self.i),evidence_sha256=H(stage),
                  brother_confirmed=stage in {"CLIENT_APPROVED","IN_PROGRESS",
                  "CLIENT_ACCEPTED","INVOICED","SETTLEMENT_CLAIMED"})
        if stage in ("CLIENT_APPROVED","CLIENT_ACCEPTED","INVOICED","SETTLEMENT_CLAIMED"):
            data["external_ref"]="DOC-123456"
        data.update(kw)
        return self.biz.advance(order_id,stage,**data)

    def test_catalog_covers_exactly_ten_platforms(self):
        self.assertEqual(len({agent for offer in SERVICES.values() for agent in offer["agents"]}),10)

    def test_empty_business_has_zero_proven_income(self):
        self.assertEqual(self.biz.dashboard()["verified_received_revenue_minor"],0)

    def test_no_client_contact_without_consent(self):
        with self.assertRaisesRegex(BusinessDenied,"CONSENT"):
            self.lead(contact_consent=False)

    def test_zero_or_negative_quote_blocked(self):
        for quote in (0,-10,1.5,True):
            with self.subTest(quote=quote), self.assertRaises(BusinessDenied):
                self.lead(quote_minor=quote)

    def test_foreign_currency_and_service_rejected(self):
        for params in ({"currency":"XYZ"},{"service":"unregistered"}):
            with self.assertRaises(BusinessDenied):self.lead(**params)

    def test_seed_phrase_not_stored(self):
        with self.assertRaisesRegex(BusinessDenied,"SECRET"):
            self.lead(customer_alias="seed phrase example")

    def test_create_lead_idempotent(self):
        a=self.lead();b=self.lead()
        self.assertEqual(a["id"],b["id"])
        self.assertEqual(self.biz.verification()["events"],1)

    def test_conflicting_idempotency_blocked(self):
        self.lead()
        with self.assertRaisesRegex(BusinessDenied,"IDEMPOTENCY"):
            self.lead(quote_minor=99999)

    def test_all_business_stages_are_serial(self):
        a=self.lead()
        for stage in STAGES[1:]:
            a=self.step(a["id"],stage)
            self.assertEqual(a["stage"],stage)
        self.assertEqual(self.biz.verification()["events"],len(STAGES))
        self.assertEqual(self.biz.dashboard()["verified_received_revenue_minor"],0)

    def test_skip_stage_rejected(self):
        a=self.lead()
        with self.assertRaisesRegex(BusinessDenied,"ILLEGAL"):
            self.step(a["id"],"DELIVERED")

    def test_payment_claim_requires_all_prior_stages(self):
        a=self.lead()
        with self.assertRaises(BusinessDenied):self.step(a["id"],"SETTLEMENT_CLAIMED")

    def test_sensitive_stage_requires_brother_approval(self):
        a=self.lead()
        for stage in ["QUALIFIED","PROPOSED"]:self.step(a["id"],stage)
        with self.assertRaisesRegex(BusinessDenied,"BROTHER_LOCAL_APPROVAL_REQUIRED"):
            self.step(a["id"],"CLIENT_APPROVED",brother_confirmed=False)

    def test_invoice_must_have_evidence_reference(self):
        a=self.lead()
        for stage in STAGES[1:STAGES.index("INVOICED")]:
            self.step(a["id"],stage)
        with self.assertRaisesRegex(BusinessDenied,"EXTERNAL_DOCUMENT_REFERENCE_REQUIRED"):
            self.step(a["id"],"INVOICED",external_ref=None)

    def test_unknown_order_refused(self):
        with self.assertRaisesRegex(BusinessDenied,"UNKNOWN_ORDER"):
            self.step("nothing","QUALIFIED")

    def test_evidence_hash_is_required(self):
        a=self.lead()
        with self.assertRaisesRegex(BusinessDenied,"EVIDENCE_SHA256_REQUIRED"):
            self.step(a["id"],"QUALIFIED",evidence_sha256="unverified")

    def test_progress_idempotent_and_conflicting_retry_denied(self):
        a=self.lead();b=self.step(a["id"],"QUALIFIED")
        again=self.biz.advance(a["id"],"QUALIFIED",event_key=KEY(1),evidence_sha256=H("QUALIFIED"))
        self.assertEqual(again["stage"],b["stage"])
        self.assertEqual(self.biz.verification()["events"],2)
        with self.assertRaises(BusinessDenied):
            self.biz.advance(a["id"],"PROPOSED",event_key=KEY(1),evidence_sha256=H("PROPOSED"))

    def test_events_immutable_with_sqlite_trigger(self):
        a=self.lead()
        with closing(sqlite3.connect(self.biz.path)) as db, db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("UPDATE business_events SET target_stage='SETTLEMENT_CLAIMED' WHERE order_id=?",(a["id"],))
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("DELETE FROM business_events WHERE order_id=?",(a["id"],))

    def test_projection_tamper_detected(self):
        a=self.lead()
        with closing(sqlite3.connect(self.biz.path)) as db, db:
            db.execute("UPDATE orders SET stage='SETTLEMENT_CLAIMED' WHERE id=?",(a["id"],))
        with self.assertRaisesRegex(BusinessDenied,"TAMPERED"):
            self.biz.verification()

    def test_event_hash_tamper_detected(self):
        self.lead()
        with closing(sqlite3.connect(self.biz.path)) as db, db:
            db.execute("DROP TRIGGER business_events_no_update")
            db.execute("UPDATE business_events SET event_hash=?",("0"*64,))
        with self.assertRaisesRegex(BusinessDenied,"BROKEN"):
            self.biz.verification()

    def test_dashboard_does_not_count_quotes_as_revenue(self):
        a=self.lead()
        self.assertEqual(self.biz.dashboard()["verified_received_revenue_minor"],0)
        self.step(a["id"],"QUALIFIED")
        self.assertTrue(self.biz.dashboard()["quotes_are_not_cash"])
        self.assertEqual(self.biz.dashboard()["automated_wallet_transfers"],"DISABLED")

    def test_reopening_db_recovers_all_stages(self):
        a=self.lead();self.step(a["id"],"QUALIFIED")
        other=ServiceFactory(Path(self.temp.name))
        self.assertEqual(other.get(a["id"])["stage"],"QUALIFIED")
        self.assertEqual(other.verification()["events"],2)

if __name__ == "__main__":unittest.main()
