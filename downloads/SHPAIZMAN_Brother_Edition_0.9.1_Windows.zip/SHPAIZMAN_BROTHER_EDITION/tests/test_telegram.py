import copy
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from shpaizman.orchestrator import Orchestrator
from shpaizman.registry import route
from shpaizman.telegram import TelegramAPI, TelegramController, validate_config
from shpaizman.security import Blocked


class TelegramTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.app=Orchestrator(Path(self.tmp.name))
        self.owner=123456789
        self.controller=TelegramController(self.app,self.owner)
        self.uid=100

    def tearDown(self):
        self.app.close()
        self.tmp.cleanup()

    def update(self,text):
        self.uid+=1
        return {"update_id":self.uid,"message":{"from":{"id":self.owner},"chat":{"id":self.owner,"type":"private"},"date":int(time.time()),"text":text}}

    def test_owner_status(self):
        self.assertIn("STOPPED",self.controller.handle(self.update("/status")))

    def test_other_user_denied(self):
        update=self.update("/resume")
        update["message"]["from"]["id"]=42
        self.assertIsNone(self.controller.handle(update))
        self.assertEqual(self.app.mode,"STOPPED")

    def test_other_chat_denied(self):
        update=self.update("/resume")
        update["message"]["chat"]["id"]=42
        self.assertIsNone(self.controller.handle(update))

    def test_group_denied(self):
        update=self.update("/resume")
        update["message"]["chat"]["type"]="group"
        self.assertIsNone(self.controller.handle(update))

    def test_forwarded_command_denied(self):
        update=self.update("/resume")
        update["message"]["forward_origin"]={"type":"user"}
        self.assertIsNone(self.controller.handle(update))

    def test_stale_command_denied(self):
        update=self.update("/resume")
        update["message"]["date"]-=200
        self.assertIsNone(self.controller.handle(update))

    def test_future_command_denied(self):
        update=self.update("/resume")
        update["message"]["date"]+=200
        self.assertIsNone(self.controller.handle(update))

    def test_bool_owner_or_update_id_denied(self):
        with self.assertRaises(ValueError):
            TelegramController(self.app,True)
        update=self.update("/resume")
        update["update_id"]=True
        self.assertIsNone(self.controller.handle(update))

    def test_replay_survives_controller_restart(self):
        a=route("albato")
        update=self.update("/task albato map_fields "+json.dumps(a.example))
        self.assertIn("Queued:",self.controller.handle(update))
        other=TelegramController(self.app,self.owner)
        self.assertIsNone(other.handle(update))
        self.assertEqual(self.app.store.summary()["tasks"],1)

    def test_telegram_stop_stops_orchestrator(self):
        self.app.start()
        self.assertIn("STOPPED",self.controller.handle(self.update("/stop")))
        self.assertEqual(self.app.mode,"STOPPED")

    def test_no_shell_or_approval_command(self):
        for command in ("/exec cmd.exe", "/shell whoami", "/approve everything", "/powershell Get-Process"):
            self.assertIn("Unknown",self.controller.handle(self.update(command)))

    def test_telegram_external_task_still_unapproved(self):
        self.controller.handle(self.update('/task cloudru list_models {}'))
        task=self.app.store.tasks()[0]
        self.assertEqual(task["approved_until"],0)

    def test_crm_summary_and_agents(self):
        self.assertIn("income_kopecks_owner_recorded",self.controller.handle(self.update("/crm")))
        self.assertEqual(self.controller.handle(self.update("/agents")).count("AGENT-"),10)

    def test_rate_limit(self):
        for _ in range(20):
            self.controller.handle(self.update("/status"))
        self.assertIn("Rate limit",self.controller.handle(self.update("/resume")))
        self.assertEqual(self.app.mode,"STOPPED")

    def test_emergency_stop_still_works_after_rate_limit(self):
        for _ in range(20):
            self.controller.handle(self.update("/status"))
        self.app.start()
        self.assertIn("STOPPED",self.controller.handle(self.update("/stop")))
        self.assertEqual(self.app.mode,"STOPPED")

    def test_api_forbids_other_recipient_before_network(self):
        api=TelegramAPI({"owner_id":self.owner,"token":"123456789:"+"TEST_ONLY_"*4})
        with patch.object(api.transport,"request") as request:
            with self.assertRaises(Blocked):
                api.call("sendMessage",{"chat_id":42,"text":"secret"})
            request.assert_not_called()

    def test_no_bot_token_configuration(self):
        with self.assertRaises(Blocked):
            validate_config({"owner_id":self.owner,"token":"invalid"})

    def test_malformed_updates_do_not_execute(self):
        for update in (None,[],{}, {"update_id":1,"message":{"from":"bad","chat":42}}, {"update_id":1,"edited_message":{}}):
            self.assertIsNone(self.controller.handle(update))
