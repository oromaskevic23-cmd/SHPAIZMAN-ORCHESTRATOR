import sqlite3
import tempfile
import unittest
from pathlib import Path
from shpaizman.beneficiary import RevenueLedger, TreasuryDenied, validate_destination


class BrotherTreasuryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger = RevenueLedger(Path(self.tmp.name))

    def tearDown(self):
        self.tmp.cleanup()

    def test_public_wallet_format_never_signs_or_verifies_ownership(self):
        x = validate_destination('0x' + 'a' * 40)
        self.assertEqual(x['transfer_authorized'], False)
        self.assertEqual(x['platform_payout_support'], 'NOT_VERIFIED')
        self.assertEqual(x['wallet_secret_required'], False)

    def test_bad_wallet_rejected(self):
        for value in ('', '0x1234', 'seed phrase', '0x' + 'x' * 40):
            with self.assertRaises(TreasuryDenied):
                validate_destination(value)

    def test_no_unapproved_chain(self):
        with self.assertRaises(TreasuryDenied):
            validate_destination('0x' + 'a' * 40, 'unknown-chain')

    def test_all_ten_platform_claims_supported_without_false_revenue(self):
        from shpaizman.registry import PLATFORMS
        for i, platform in enumerate(PLATFORMS):
            r = self.ledger.record_unverified_claim(platform=platform,
                    reference=f'example:receipt_{i:02}', amount='12.50',
                    currency='USD', evidence='Unverified provider-reported invoice #12345')
            self.assertEqual(r['status'], 'UNVERIFIED_EXTERNAL_CLAIM')
            self.assertEqual(r['wallet_transfer'], 'NOT_ATTEMPTED')
        self.assertEqual(self.ledger.verify_chain()['events'], 10)
        self.assertEqual(self.ledger.verify_chain()['settled_revenue'], 'NOT_VERIFIED')

    def test_idempotent_receipts(self):
        for i in range(2):
            if i == 0:
                self.ledger.record_unverified_claim(platform='albato',
                    reference='provider:invoice12345',amount='1',currency='USD',
                    evidence='Local business receipt, not settled or validated')
            else:
                with self.assertRaises(sqlite3.IntegrityError):
                    self.ledger.record_unverified_claim(platform='albato',
                        reference='provider:invoice12345',amount='1',currency='USD',
                        evidence='Local business receipt, not settled or validated')

    def test_ledger_is_append_only(self):
        self.ledger.record_unverified_claim(platform='albato',
            reference='provider:invoice12345',amount='1',currency='USD',
            evidence='Local business receipt, not settled or validated')
        with sqlite3.connect(self.ledger.db) as db:
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute('DELETE FROM ledger_events')

    def test_financial_amounts_validated_without_floats(self):
        for amount in ['nan', '-1', '0', '0.123456789', '1e99']:
            with self.assertRaises(TreasuryDenied):
                self.ledger.record_unverified_claim(platform='albato',
                  reference='provider:invoice12345', amount=amount,currency='USD',
                  evidence='Local business receipt, not settled or validated')

    def test_secret_in_evidence_refused(self):
        with self.assertRaises(TreasuryDenied):
            self.ledger.record_unverified_claim(platform='albato',
               reference='provider:invoice12345',amount='1',currency='USD',
               evidence='Please use seed phrase to unlock brother wallet')

    def test_unknown_platform_refused(self):
        with self.assertRaises(TreasuryDenied):
            self.ledger.record_unverified_claim(platform='fake-agent',
              reference='provider:invoice12345',amount='1',currency='USD',
              evidence='Local business receipt, not settled or validated')


if __name__=='__main__':
    unittest.main()
