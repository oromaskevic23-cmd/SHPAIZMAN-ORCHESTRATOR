"""Synthetic protocol fixtures ONLY. These tests prove zero live connections."""
import unittest
from unittest.mock import patch
from shpaizman.registry import route
from shpaizman.security import RemoteFailure
from shpaizman.connectors.transport import Transport


class ProtocolFixture:
    def __init__(self,value):
        self.value=value
        self.calls=[]

    def request(self,*args,**kwargs):
        self.calls.append((args,kwargs))
        value=self.value
        if callable(value):
            value=value(args)
        # A fabricated protocol receipt exists only inside this test double.
        return value,{"transport":"REAL_HTTPS","http_status":200,"response_sha256":"fixture-not-evidence"}


CASES={
    "albato": ({"token":"test-only-token"},{"data":[{"id":12}]},{}),
    "aimylogic": ({"token":"testonlytoken","isolated_test_bot":True},{"data":{"replies":[{"type":"text","text":"fixture"}]}},{"query":"fixture"}),
    "twin": ({"token":"test-only-token"},{"items":[{"status":"DELIVERED"}]},{}),
    "gigachat": ({"token":"test-only-token"},{"data":[{"id":"fixture-model"}]},{}),
    "yandex": ({"token":"test-only-token","folder_id":"fixture-folder"},{"assistants":[{"id":"assistant-1"}]},{}),
    "nodul": ({"webhook_url":"https://hook.nodul.ru/fixture","isolated_free_workflow":True},lambda args:{"status":"completed","request_id":args[3]["request_id"],"result":{"ok":True}},{}),
    "bitrix24": ({"webhook_url":"https://fixture.bitrix24.ru/rest/1/fixturesecret/"},{"result":{"ID":"123"}},{}),
    "cloudru": ({"token":"test-only-token"},{"data":[{"id":"fixture-model"}]},{})
}


class ConnectorTests(unittest.TestCase):
    def test_nodul_http200_without_completion_is_not_verified(self):
        config,_,payload=CASES["nodul"]
        connector=route("nodul").connector(config,ProtocolFixture({"status":"accepted"}))
        with self.assertRaises(RemoteFailure):
            connector.execute("run_workflow",payload)

    def test_bitrix_http200_api_error_is_failure(self):
        config,_,payload=CASES["bitrix24"]
        connector=route("bitrix24").connector(config,ProtocolFixture({"error":"ACCESS_DENIED"}))
        with self.assertRaises(RemoteFailure):
            connector.execute("read_profile",payload)

    def test_models_invalid_records_rejected(self):
        for platform in ("gigachat","cloudru"):
            connector=route(platform).connector(CASES[platform][0],ProtocolFixture({"data":[{}]}))
            with self.assertRaises(RemoteFailure):
                connector.execute("list_models",{})

    def test_redirect_does_not_send_credentials_to_new_host(self):
        class Response:
            status=302
        class Connection:
            def request(self,*args): pass
            def getresponse(self): return Response()
            def close(self): pass
        with patch("socket.getaddrinfo",return_value=[(2,1,6,"",("8.8.8.8",443))]), patch("shpaizman.connectors.transport.PinnedHTTPS",return_value=Connection()) as constructor:
            with self.assertRaises(RemoteFailure):
                Transport().request("GET","https://api.giga.chat/v1/models",{"Authorization":"Bearer fixture"},hosts=("api.giga.chat",))
            self.assertEqual(constructor.call_count,1)


def contract_test(platform):
    def test(self):
        config,value,payload=CASES[platform]
        fixture=ProtocolFixture(value)
        a=route(platform)
        result=a.connector(config,fixture).execute(a.connector.operations[0],payload)
        self.assertEqual(len(fixture.calls),1)
        self.assertEqual(result["operation"],a.connector.operations[0])
        self.assertIsInstance(result["data"],dict)
        self.assertEqual(result["receipt"]["response_sha256"],"fixture-not-evidence")
    return test


for platform in CASES:
    setattr(ConnectorTests,"test_"+platform+"_synthetic_protocol_contract",contract_test(platform))
