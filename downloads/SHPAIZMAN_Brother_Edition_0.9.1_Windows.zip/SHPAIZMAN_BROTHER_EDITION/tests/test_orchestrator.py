from pathlib import Path
import tempfile
import time
import unittest
from shpaizman.orchestrator import Orchestrator
from shpaizman.registry import route
from shpaizman.security import Blocked
from shpaizman.resources import ResourceManager


class AllowResources(ResourceManager):
    def admit(self,pids=()):
        return True,"TEST_FIXTURE_RESOURCE_ADMISSION"


class DenyResources(ResourceManager):
    def admit(self,pids=()):
        return False,"TEST_FIXTURE_LOW_RAM"


def slow_worker(sender, task, config):
    time.sleep(30)


def crash_worker(sender, task, config):
    import os
    os._exit(9)


def network_error_worker(sender,task,config):
    sender.send({"state":"FAILED","retryable":True,"result":{"reason":"TEST_NETWORK_FAILURE"}})
    sender.close()


class OrchestratorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.app=Orchestrator(self.root,resource_manager=AllowResources(self.root))

    def tearDown(self):
        self.app.close()
        self.tmp.cleanup()

    def submit(self,platform="albato",timeout=30):
        a=route(platform)
        return self.app.submit(platform,a.operation,a.example,timeout)

    def wait_state(self,job,states,timeout=10):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            value=self.app.store.task(job)["state"]
            if value in states:
                return value
            time.sleep(0.03)
        self.fail(f"Timeout; state={value}; mode={self.app.mode}; reason={self.app.reason}")

    def test_real_process_execution_all_ten(self):
        jobs=[self.submit(p) for p in self.app.agents]
        self.app.start()
        for job in jobs:
            self.assertEqual(self.wait_state(job,{"SUCCEEDED_LOCAL","FAILED"},30),"SUCCEEDED_LOCAL")

    def test_start_pause_stop(self):
        self.assertEqual(self.app.mode,"STOPPED")
        self.app.start()
        self.assertEqual(self.app.mode,"RUNNING")
        self.app.pause()
        job=self.submit()
        time.sleep(0.25)
        self.assertEqual(self.app.store.task(job)["state"],"QUEUED")
        self.app.stop()
        self.assertEqual(self.app.store.task(job)["state"],"CANCELLED")

    def test_timeout_terminates_real_process(self):
        self.app.worker_target=slow_worker
        job=self.submit(timeout=1)
        self.app.start()
        self.assertEqual(self.wait_state(job,{"TIMED_OUT"}),"TIMED_OUT")
        self.assertEqual(len(self.app.active),0)

    def test_stop_cancels_running_and_queued(self):
        self.app.worker_target=slow_worker
        first=self.submit()
        second=self.submit()
        self.app.start()
        self.wait_state(first,{"RUNNING"})
        self.app.stop()
        self.assertEqual(self.app.store.task(first)["state"],"CANCELLED")
        self.assertEqual(self.app.store.task(second)["state"],"CANCELLED")
        self.assertFalse(self.app.active)

    def test_worker_crash_becomes_failure(self):
        self.app.worker_target=crash_worker
        job=self.submit()
        self.app.start()
        self.assertEqual(self.wait_state(job,{"FAILED"}),"FAILED")

    def test_two_process_limit_and_unique_platform(self):
        self.app.worker_target=slow_worker
        for p in ("albato","aimylogic","nodul","albato"):
            self.submit(p)
        self.app.start()
        deadline=time.monotonic()+5
        while len(self.app.active)<2 and time.monotonic()<deadline:
            time.sleep(0.05)
        self.assertEqual(len(self.app.active),2)
        self.assertEqual(len({a[2]["platform"] for a in self.app.active.values()}),2)
        time.sleep(0.3)
        self.assertEqual(len(self.app.active),2)

    def test_low_memory_keeps_tasks_queued(self):
        self.app.resources=DenyResources(self.root)
        job=self.submit()
        self.app.start()
        time.sleep(0.3)
        self.assertEqual(self.app.store.task(job)["state"],"QUEUED")
        self.assertFalse(self.app.active)

    def test_external_missing_credentials_blocks_without_network(self):
        job=self.app.submit("cloudru","list_models",{})
        self.app.store.approve(job)
        self.app.start()
        self.assertEqual(self.wait_state(job,{"BLOCKED"}),"BLOCKED")

    def test_external_waits_for_local_approval_while_running(self):
        self.app.start()
        job=self.app.submit("cloudru","list_models",{})
        time.sleep(0.3)
        self.assertEqual(self.app.store.task(job)["state"],"QUEUED")
        self.assertEqual(self.app.store.task(job)["attempts"],0)
        self.app.store.approve(job)
        self.assertEqual(self.wait_state(job,{"BLOCKED"}),"BLOCKED")

    def test_local_success_never_means_connected(self):
        job=self.submit()
        self.app.start()
        self.wait_state(job,{"SUCCEEDED_LOCAL"})
        self.assertEqual(next(s for s in self.app.statuses() if s["platform"]=="albato")["connection"],"NOT_CONNECTED")

    def test_job_cannot_run_shell(self):
        with self.assertRaises(Blocked):
            self.app.submit("albato","exec",{"command":"calc.exe"})

    def test_close_preserves_pending_queue(self):
        job=self.submit()
        self.app.close()
        self.app=Orchestrator(self.root,resource_manager=AllowResources(self.root))
        self.assertEqual(self.app.store.task(job)["state"],"QUEUED")
        self.assertEqual(self.app.mode,"STOPPED")

    def test_read_retry_is_bounded(self):
        self.app.worker_target=network_error_worker
        job=self.submit()
        self.app.start()
        self.wait_state(job,{"FAILED"},15)
        self.assertEqual(self.app.store.task(job)["attempts"],3)

    def test_mutating_operation_not_retried(self):
        self.app.worker_target=network_error_worker
        job=self.submit("aimylogic")
        self.app.start()
        self.wait_state(job,{"FAILED"})
        self.assertEqual(self.app.store.task(job)["attempts"],1)

    def test_stop_individual_agent(self):
        self.app.worker_target=slow_worker
        job=self.submit()
        self.app.start()
        self.wait_state(job,{"RUNNING"})
        self.app.enable_agent("albato",False)
        self.assertEqual(self.app.store.task(job)["state"],"CANCELLED")
        self.assertEqual(self.app.statuses()[0]["module"],"OFFLINE")
