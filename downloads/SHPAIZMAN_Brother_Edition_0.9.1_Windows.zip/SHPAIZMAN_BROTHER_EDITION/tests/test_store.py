from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest

from shpaizman.legacy import Shpaizman, open_db
from shpaizman.security import Blocked
from shpaizman.store import Store, STATES, TRANSITIONS


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.store = Store(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def add(self):
        return self.store.enqueue_task("albato","map_fields",{"source":{},"mapping":{}})

    def test_migration_preserves_recovered_crm_and_jobs(self):
        old = Shpaizman(self.root/"shpaizman.sqlite3")
        client = old.add_client("Before migration")
        old.add_deal(client,"albato","Existing deal",1500)
        old.enqueue("albato","Old offline draft")
        new = Store(self.root)
        self.assertEqual(new.clients()[0]["name"],"Before migration")
        self.assertEqual(new.deals()[0]["amount_rub"],1500)
        self.assertEqual(len(new.jobs()),1)

    def test_restart_persistence(self):
        job = self.add()
        self.assertEqual(Store(self.root).task(job)["state"],"QUEUED")

    def test_crashed_running_not_replayed(self):
        job = self.add()
        self.store.claim()
        new = Store(self.root)
        new.recover()
        self.assertEqual(new.task(job)["state"],"INTERRUPTED")
        self.assertIsNone(new.claim())

    def test_atomic_claim_between_competing_workers(self):
        job = self.add()
        with ThreadPoolExecutor(8) as pool:
            claimed = list(pool.map(lambda _:self.store.claim(),range(8)))
        self.assertEqual(sum(x is not None for x in claimed),1)
        self.assertEqual(next(x for x in claimed if x)["id"],job)

    def test_all_state_edges_and_terminal_immutability(self):
        for source in STATES:
            for target in STATES:
                job = self.add()
                with open_db(self.store.db_path) as db:
                    db.execute("UPDATE work_items SET state=? WHERE id=?",(source,job))
                accepted = self.store.transition(job,target,{"fixture":True})
                self.assertEqual(accepted,target in TRANSITIONS.get(source,set()),(source,target))

    def test_retry_backoff_respected(self):
        job = self.add()
        self.store.claim()
        self.store.transition(job,"RETRY_WAIT",{},time.time()+10)
        self.assertIsNone(self.store.claim())

    def test_disabled_agent_not_claimed(self):
        self.add()
        self.store.enable_agent("albato",False)
        self.assertIsNone(self.store.claim())

    def test_busy_agent_not_dispatched_twice(self):
        self.add()
        self.assertIsNone(self.store.claim(("albato",)))

    def test_approval_bound_to_task_digest(self):
        job = self.add()
        self.store.approve(job)
        t = self.store.task(job)
        self.assertEqual(t["digest"],t["approval_digest"])
        self.assertGreater(t["approved_until"],time.time())

    def test_expired_remote_approval_stays_queued(self):
        job=self.store.enqueue_task("cloudru","list_models",{},True)
        self.store.approve(job)
        with open_db(self.store.db_path) as db:
            db.execute("UPDATE work_items SET approved_until=? WHERE id=?",(time.time()-1,job))
        self.assertIsNone(self.store.claim())
        self.assertEqual(self.store.task(job)["state"],"QUEUED")

    def test_storage_limit_applies_on_every_connection(self):
        for _ in range(2):
            with open_db(self.store.db_path) as db:
                self.assertEqual(db.execute("PRAGMA max_page_count").fetchone()[0],32768)

    def test_queue_capacity(self):
        for _ in range(100):
            self.add()
        with self.assertRaises(ValueError):
            self.add()

    def test_payload_limits(self):
        for payload in ([1],{"text":"x"*16001},{"number":float("nan")}):
            with self.assertRaises(ValueError):
                self.store.enqueue_task("albato","map_fields",payload)

    def test_backup_restore_persistence_and_revocation(self):
        cid = self.store.add_client("Customer")
        job = self.add()
        self.store.approve(job)
        backup = self.store.backup()
        self.store.add_client("After backup")
        self.store.restore(backup)
        self.assertEqual(len(self.store.clients()),1)
        self.assertEqual(self.store.clients()[0]["id"],cid)
        self.assertEqual(self.store.task(job)["approved_until"],0)

    def test_corrupt_backup_does_not_replace_database(self):
        self.store.add_client("Keep me")
        file = self.root/"bad.sqlite3"
        file.write_bytes(b"garbage")
        with self.assertRaises((sqlite3.DatabaseError,ValueError)):
            self.store.restore(file)
        self.assertEqual(self.store.clients()[0]["name"],"Keep me")

    def test_backup_with_trigger_denied(self):
        backup = self.store.backup()
        with sqlite3.connect(backup) as db:
            db.execute("CREATE TRIGGER unwanted AFTER INSERT ON clients BEGIN DELETE FROM deals; END")
        with self.assertRaises(ValueError):
            self.store.restore(backup)

    def test_backup_rotation(self):
        for _ in range(9):
            self.store.backup()
        self.assertEqual(len(list((self.root/"backups").glob("*.sqlite3"))),7)

    def test_income_is_paid_not_planned(self):
        client = self.store.add_client("Example")
        deal = self.store.add_deal(client,"albato","Plan",50000)
        self.assertEqual(self.store.summary()["income_kopecks_owner_recorded"],0)
        self.store.record_payment(deal,12345,"receipt-test-001")
        self.assertEqual(self.store.summary()["income_kopecks_owner_recorded"],12345)
        with self.assertRaises(sqlite3.IntegrityError):
            self.store.record_payment(deal,12345,"receipt-test-001")

    def test_foreign_key_and_money_constraints(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.store.record_payment("unknown",100,"test")
        for value in (True,-1,1.5,0):
            with self.assertRaises(ValueError):
                self.store.record_payment("unknown",value,"test")

    def test_crm_edit_and_stage(self):
        cid = self.store.add_client("Before")
        self.store.update_client(cid,"After","Note")
        deal = self.store.add_deal(cid,"bitrix24","Work")
        self.store.set_deal_stage(deal,"in_progress")
        self.assertEqual(self.store.clients()[0]["name"],"After")
        self.assertEqual(self.store.deals()[0]["status"],"in_progress")

    def test_no_secret_in_backup(self):
        secret = self.root/"secrets"
        secret.mkdir()
        (secret/"test.dpapi").write_bytes(b"UNIQUE_SECRET_MARKER")
        self.assertNotIn(b"UNIQUE_SECRET_MARKER",self.store.backup().read_bytes())

    def test_free_grant_counter_is_atomic(self):
        config={"free_access":{"owner_confirmed":True,"billing_disabled":True,"expires_at":time.time()+300,
            "evidence":"fixture local test only", "operations":["list_models"], "max_requests":1}}
        self.store.reserve_request("cloudru","list_models",config)
        with self.assertRaises(Blocked):
            self.store.reserve_request("cloudru","list_models",config)
