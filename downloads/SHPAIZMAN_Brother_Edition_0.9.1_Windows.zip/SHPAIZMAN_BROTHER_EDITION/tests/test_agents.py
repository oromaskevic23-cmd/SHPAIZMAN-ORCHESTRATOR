import copy
import unittest
from shpaizman.registry import discover, route


class AgentTests(unittest.TestCase):
    def test_registry_exact_identity(self):
        agents = discover()
        self.assertEqual(len(agents), 10)
        self.assertEqual({a.id for a in agents.values()}, {f"AGENT-{i:02d}" for i in range(1,11)})
        self.assertEqual(len({a.local_handler.__module__ for a in agents.values()}), 10)
        self.assertEqual(len({a.connector.__module__ for a in agents.values()}), 10)

    def test_routing_by_profession(self):
        for agent in discover().values():
            self.assertEqual(route(agent.profession).platform, agent.platform)
            self.assertEqual(route(agent.id).platform, agent.platform)

    def test_unknown_routing(self):
        for key in ("__import__", "cmd.exe", "../albato", "Administrator"):
            with self.assertRaises(ValueError):
                route(key)

    def test_field_mapping_missing(self):
        a = route("albato")
        with self.assertRaises(ValueError):
            a.execute_local(a.operation, {"source": {}, "mapping": {"name": "missing"}})

    def test_dialogue_infinite_region(self):
        a = route("aimylogic")
        with self.assertRaises(ValueError):
            a.execute_local(a.operation, {"start": "a", "states": [{"id":"a","reply":"Hello","next":["b","end"]},
                {"id":"b","reply":"Loop","next":["b"]}, {"id":"end","reply":"Bye","next":[]}]})

    def test_voice_over_budget(self):
        a = route("tomoru")
        p = copy.deepcopy(a.example)
        p["steps"][0]["listen_seconds"] = 60
        with self.assertRaises(ValueError):
            a.execute_local(a.operation, p)

    def test_fallback_chooses_available_channel(self):
        a = route("twin")
        self.assertEqual(a.execute_local(a.operation,a.example)["data"]["primary"], "EMAIL")

    def test_language_batch_reduces_duplicate(self):
        a = route("gigachat")
        self.assertEqual(a.execute_local(a.operation,a.example)["data"]["duplicates_removed"],1)

    def test_yandex_rejects_uri_injection(self):
        a = route("yandex")
        p = {**a.example,"folder_id":"../../secrets"}
        with self.assertRaises(ValueError):
            a.execute_local(a.operation,p)

    def test_workflow_cycle(self):
        a = route("nodul")
        with self.assertRaises(ValueError):
            a.execute_local(a.operation,{"nodes":["a","b"],"edges":[["a","b"],["b","a"]]})

    def test_crm_deduplicates_email_case(self):
        a = route("bitrix24")
        p = {"leads":[{"name":"A","email":"A@example.invalid"},{"name":"B","email":"a@example.invalid"}]}
        self.assertEqual(a.execute_local(a.operation,p)["data"]["duplicates_removed"],1)

    def test_mws_refuses_shell_capability(self):
        a = route("mws")
        with self.assertRaises(ValueError):
            a.execute_local(a.operation,{**a.example,"capabilities":["os.exec"]})

    def test_cloud_cost_filter_no_inference(self):
        a = route("cloudru")
        r = a.execute_local(a.operation,a.example)["data"]
        self.assertEqual(r["zero_price_candidates_from_input"],["example-free"])
        self.assertFalse(r["inference_enabled"])

    def test_nonfinite_price_denied(self):
        a = route("cloudru")
        for price in ("NaN","Infinity","-1"):
            with self.assertRaises(ValueError):
                a.execute_local(a.operation,{"catalog":[{"id":"m","input_rub_per_million":price,"output_rub_per_million":"0"}]})


def valid_test(platform):
    def test(self):
        a = route(platform)
        result = a.execute_local(a.operation, a.example)
        a.verify(a.operation,a.example,result)
        self.assertEqual(result["mode"],"LOCAL_ALGORITHM")
        self.assertFalse(result["external_effects"])
        self.assertIsInstance(result["data"],dict)
    return test


def malformed_test(platform):
    def test(self):
        a = route(platform)
        with self.assertRaises(ValueError):
            a.execute_local(a.operation,{"command":"powershell.exe", "unapproved":True})
        with self.assertRaises(ValueError):
            a.execute_local("shell",a.example)
    return test


for platform in discover():
    setattr(AgentTests,"test_"+platform+"_real_local_execution",valid_test(platform))
    setattr(AgentTests,"test_"+platform+"_contract_denial",malformed_test(platform))
