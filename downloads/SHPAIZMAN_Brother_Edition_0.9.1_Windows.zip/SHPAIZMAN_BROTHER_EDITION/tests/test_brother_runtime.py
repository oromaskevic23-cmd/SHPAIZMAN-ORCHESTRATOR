import hashlib
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from shpaizman import ai_draft
from shpaizman.orchestrator import Orchestrator
from shpaizman.pairing import match_owner
from shpaizman.registry import route
from shpaizman.security import Blocked
from shpaizman.telegram import TelegramAPI, TelegramController


class BrotherRuntimeTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.app = Orchestrator(Path(temp.name))
        self.addCleanup(self.app.close)
        self.model = ai_draft.MODELS[0]
        self.app.store.set_setting("ollama_model", self.model)
        self.bot = TelegramController(self.app, 31)
        self.now = int(time.time())

    def message(self, text, seq=5, uid=31):
        return {"update_id": seq, "message": {"from": {"id": uid, "is_bot": False},
                "chat": {"id": uid, "type": "private"}, "date": self.now, "text": text}}

    def test_ask_uses_same_queue_as_desktop_and_replay_creates_one_job(self):
        request = self.message("/ask bitrix24 Проверь поля карточки")
        job = self.bot.handle(request).split()[-1]
        self.assertIsNone(self.bot.handle(request))
        row = self.app.store.task(job)
        self.assertEqual(row["remote"], 0)
        self.assertEqual(json.loads(row["payload"]), {"prompt": "Проверь поля карточки", "model": self.model})
        self.assertEqual(len(self.app.store.tasks()), 1)
        self.assertEqual(self.app.mode, "STOPPED")

    def test_wrong_sender_and_unconfigured_model_cannot_create_job(self):
        self.assertIsNone(self.bot.handle(self.message("/ask albato x", uid=32)))
        self.app.store.set_setting("ollama_model", None)
        self.assertIn("SETTINGS", self.bot.handle(self.message("/ask albato x")))
        self.assertFalse(self.app.store.tasks())

    def test_task_cannot_choose_model_or_endpoint(self):
        for field in ("model", "url"):
            with self.assertRaises(ValueError):
                self.app.submit("albato", "ai_draft", {"prompt": "x", field: "override"})

    def test_cloud_model_rejected_before_chat(self):
        with patch.object(ai_draft, "post_local", return_value={"remote_host": "example",
                          "details": {"format": "gguf"}}) as post:
            with self.assertRaises(Blocked):
                ai_draft.generate(route("bitrix24"), {"prompt": "x", "model": self.model})
            self.assertEqual(post.call_count, 1)

    def test_incomplete_or_mismatched_answer_rejected(self):
        for done, model, text in [(False, self.model, "partial"), (True, self.model, ""), (True, "other", "x")]:
            with self.subTest(done=done, model=model, text=text):
                with patch.object(ai_draft, "post_local", side_effect=[
                        {"details": {"format": "gguf"}},
                        {"done": done, "model": model, "message": {"content": text}}]):
                    with self.assertRaises(Blocked):
                        ai_draft.generate(route("bitrix24"), {"prompt": "x", "model": self.model})

    def test_full_result_can_be_read_in_pages(self):
        job = self.app.submit("bitrix24", "ai_draft", {"prompt": "plan"})
        self.app.store.claim()
        output = "🔷"*1600+"END"
        self.app.store.transition(job, "SUCCEEDED_LOCAL", {"mode": "LOCAL_MODEL", "text": output,
                                  "response_sha256": hashlib.sha256(output.encode()).hexdigest()})
        first = self.bot.handle(self.message("/result " + job))
        self.assertIn("/result " + job + " 2", first)
        self.assertLess(len(first.encode("utf-16-le")) // 2, 4096)
        self.assertTrue(self.bot.handle(self.message("/result " + job + " 2", 6)).endswith("END"))

    def test_webhook_refused(self):
        api = TelegramAPI({"owner_id": 31, "token": "123456:" + "x"*24})
        with patch.object(api, "call", side_effect=[{"id": 10, "is_bot": True}, {"url": "existing"}]):
            with self.assertRaises(Blocked):
                api.check()

    def test_private_pairing_uses_code_and_timestamp(self):
        u = self.message("/start 123xyz")
        self.assertEqual(match_owner(u, "123xyz", self.now), 31)
        self.assertIsNone(match_owner(u, "another", self.now))
        self.assertIsNone(match_owner(u, "123xyz", self.now+5))
        u["message"]["forward_origin"] = {}
        self.assertIsNone(match_owner(u, "123xyz", self.now))

    def test_poller_retries_a_reply_without_submitting_a_second_job(self):
        from shpaizman.security import RemoteFailure
        from shpaizman.telegram import TelegramService
        from unittest.mock import Mock

        service = TelegramService(self.app, {"owner_id": 31, "token": "123456:"+"x"*24})
        updates = [self.message('/task albato map_fields {"source":{"x":"B"},"mapping":{"name":"x"}}')]
        requests = []
        rejected = False

        def transport(method, url, headers, payload, **options):
            nonlocal rejected
            api_method = url.rsplit("/", 1)[1]
            requests.append((api_method, dict(payload)))
            if api_method == "getMe":
                result = {"id": 45, "username": "test", "is_bot": True}
            elif api_method == "getWebhookInfo":
                result = {"url": ""}
            elif api_method == "getUpdates":
                if payload["offset"]:
                    service.shutdown.set()
                    result = []
                else:
                    result = updates
            else:
                if not rejected:
                    rejected = True
                    raise RemoteFailure("NETWORK_UNAVAILABLE")
                result = {"message_id": 6}
            return {"ok": True, "result": result}, {}
        service.api.transport.request = Mock(side_effect=transport)
        service._loop()
        replies = [p for method, p in requests if method == "sendMessage"]
        self.assertEqual(len(replies), 2)
        self.assertEqual(replies[0], replies[1])
        self.assertEqual(replies[0]["chat_id"], 31)
        self.assertEqual(len(self.app.store.tasks()), 1)
        self.assertIsNone(self.app.store.get_setting("telegram_pending_reply"))
