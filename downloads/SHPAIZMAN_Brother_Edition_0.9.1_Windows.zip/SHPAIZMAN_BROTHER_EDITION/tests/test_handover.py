import tempfile
import unittest
from pathlib import Path
from shpaizman.handover import build_handover, write_handover


class EnterpriseHandoverTests(unittest.TestCase):
    def test_ten_distinct_agents_and_platforms(self):
        data = build_handover(Path.cwd())
        self.assertEqual(len(data['platform_agents']), 10)
        self.assertEqual(len(set(a['agent_id'] for a in data['platform_agents'])), 10)
        self.assertEqual(len(set(a['platform'] for a in data['platform_agents'])), 10)

    def test_no_invisible_automation_or_money_movement(self):
        data=build_handover(Path.cwd())
        self.assertFalse(data['permissions']['admin_elevation'])
        self.assertFalse(data['permissions']['automatic_wallet_transfer'])
        self.assertFalse(data['permissions']['purchases'])
        self.assertFalse(data['guaranteed_income'])
        self.assertTrue(all(x['external_connection']=='UNVERIFIED' for x in data['platform_agents']))

    def test_sensitive_stages_require_brother_approval(self):
        data=build_handover(Path.cwd())
        stages={x['id']:x for x in data['stages']}
        for stage in ('03_INSTALL','05_ACCOUNTS','06_FINANCE','07_EXTERNAL'):
            self.assertTrue(stages[stage]['approval_required'])

    def test_report_is_created_once_without_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'handover.json'
            result=write_handover(Path(td),output)
            self.assertEqual(result['status'],'PLAN_ONLY')
            self.assertTrue(output.exists())
            with self.assertRaises(FileExistsError):
                write_handover(Path(td),output)


if __name__=='__main__':
    unittest.main()
