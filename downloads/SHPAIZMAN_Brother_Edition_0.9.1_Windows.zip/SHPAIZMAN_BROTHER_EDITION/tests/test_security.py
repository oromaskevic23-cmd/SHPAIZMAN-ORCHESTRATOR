import copy
from pathlib import Path
import os
import tempfile
import time
import unittest
from unittest.mock import patch

from shpaizman.security import Blocked, InstanceLock, Vault, dpapi, validate_grant
from shpaizman.connectors.transport import Transport, validate_url
from shpaizman.registry import discover
from shpaizman.local_ai import LocalAI


class SecurityTests(unittest.TestCase):
    def test_zero_cost_denied_without_evidence(self):
        for config in ({},{"free_access":{"owner_confirmed":True}},{"token":"some-key"}):
            with self.assertRaises(Blocked):
                validate_grant(config,"list_models")

    def test_expired_overbroad_or_paid_grant_denied(self):
        good={"free_access":{"owner_confirmed":True,"billing_disabled":True,"expires_at":time.time()+300,
            "evidence":"test fixture evidence", "operations":["list_models"],"max_requests":20}}
        validate_grant(good,"list_models")
        for key,value in (("expires_at",0),("expires_at",time.time()+32*86400),("billing_disabled",False),
                          ("max_requests",0),("max_requests",True),("evidence","")):
            config=copy.deepcopy(good)
            config["free_access"][key]=value
            with self.assertRaises(Blocked):
                validate_grant(config,"list_models")
        with self.assertRaises(Blocked):
            validate_grant(good,"chat.completions")

    def test_no_cloud_inference_capability(self):
        for agent in discover().values():
            self.assertNotIn("chat.completions",agent.connector.operations)
            self.assertNotIn("generate",agent.connector.operations)

    def test_endpoint_attack_vectors(self):
        for url in ("http://api.giga.chat/v1/models","https://api.giga.chat.attacker.invalid/x",
                    "https://api.giga.chat@127.0.0.1/x","https://api.giga.chat:80/x",
                    "file:///etc/passwd","https://127.0.0.1/x","https://api.giga.chat/x#token",
                    "https://api.giga.chat/\r\nHeader:bad","https://api.giga.chat\\evil.invalid/x"):
            with self.assertRaises(Blocked):
                validate_url(url,("api.giga.chat",))

    def test_dns_private_address_rejected_before_connect(self):
        with patch("socket.getaddrinfo",return_value=[(2,1,6,"",("127.0.0.1",443))]), patch("socket.create_connection") as connect:
            with self.assertRaises(Blocked):
                Transport().request("GET","https://api.giga.chat/v1/models",{},hosts=("api.giga.chat",))
            connect.assert_not_called()

    def test_bitrix_secret_path_injection(self):
        c=discover()["bitrix24"].connector
        for url in ("https://x.bitrix24.ru/rest/1/keykeykey/../../other/", "https://x.bitrix24.ru/rest/1/keykeykey/?x=y", "https://bitrix24.ru.evil.invalid/rest/1/keykeykey/"):
            with self.assertRaises(Blocked):
                c({"webhook_url":url}).validate()

    def test_nodul_fast_mode_denied(self):
        c=discover()["nodul"].connector
        with self.assertRaises(Blocked):
            c({"webhook_url":"https://hook.nodul.ru/test?__ln.fast=1","isolated_free_workflow":True}).validate()

    def test_unavailable_products_cannot_fake_connection(self):
        for name in ("tomoru","mws"):
            c=discover()[name].connector({"token":"test-only"})
            with self.assertRaises(Blocked):
                c.validate()

    def test_instance_lock(self):
        with tempfile.TemporaryDirectory() as d:
            lock=InstanceLock(Path(d)/"app.lock")
            try:
                with self.assertRaises(Blocked):
                    InstanceLock(Path(d)/"app.lock")
            finally:
                lock.close()
            InstanceLock(Path(d)/"app.lock").close()

    def test_secret_slot_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            vault=Vault(Path(d))
            with self.assertRaises(ValueError):
                vault.load("../../secret")

    @unittest.skipUnless(os.name == "nt","Windows DPAPI requires a real Windows execution")
    def test_windows_dpapi_roundtrip_and_ciphertext(self):
        raw=b"test-secret-only-no-real-token"
        encrypted=dpapi(raw)
        self.assertNotIn(raw,encrypted)
        self.assertEqual(dpapi(encrypted,True),raw)
        with tempfile.TemporaryDirectory() as d:
            vault=Vault(Path(d))
            vault.save("telegram",{"token":"fixture-secret","owner_id":123})
            self.assertEqual(vault.load("telegram")["owner_id"],123)

    @unittest.skipIf(os.name == "nt","Non-Windows deny path only")
    def test_no_plaintext_secret_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(Blocked):
                Vault(Path(d)).save("telegram",{"token":"secret"})
            self.assertFalse(list(Path(d).rglob("*.dpapi")))

    def test_local_model_off_by_default(self):
        with self.assertRaises(Blocked):
            LocalAI({})
