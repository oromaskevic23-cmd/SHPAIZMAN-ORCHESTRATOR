"""Opt-in single shared llama.cpp engine. Loopback only, no model download."""
import http.client
import json
import threading
import time

from .resources import memory
from .security import Blocked, Vault

MODEL_LOCK = threading.Lock()


class LocalAI:
    def __init__(self, config):
        self.config = config
        if config.get("enabled") is not True or config.get("license_reviewed") is not True:
            raise Blocked("LOCAL_AI is disabled; install and review a model separately")
        if not isinstance(config.get("model"), str) or not 1 <= len(config["model"]) <= 200:
            raise Blocked("LOCAL_AI exact local model identifier required")
        if not isinstance(config.get("model_sha256"), str) or len(config["model_sha256"]) != 64:
            raise Blocked("Record the locally verified GGUF SHA-256")

    def generate(self, prompt):
        if not isinstance(prompt, str) or not 1 <= len(prompt) <= 4000:
            raise ValueError("Prompt limit: 4000 characters")
        m = memory()
        if m["available"] is None or m["available"] < 3*1024**3:
            raise Blocked("LOCAL_AI requires at least 3 GiB currently available RAM")
        if not MODEL_LOCK.acquire(blocking=False):
            raise Blocked("The shared LOCAL_AI engine is busy")
        connection = http.client.HTTPConnection("127.0.0.1", 8081, timeout=60)
        start = time.monotonic()
        try:
            payload = {"model": self.config["model"], "messages": [{"role": "user", "content": prompt}],
                       "max_tokens": 256, "temperature": 0.2, "stream": False}
            connection.request("POST", "/v1/chat/completions", json.dumps(payload).encode(), {"Content-Type": "application/json"})
            response = connection.getresponse()
            raw = response.read(65537)
            if response.status != 200 or len(raw) > 65536:
                raise Blocked("LOCAL_AI response rejected")
            data = json.loads(raw)
            content = data["choices"][0]["message"]["content"]
            if not isinstance(content, str):
                raise ValueError("Invalid local model result")
            elapsed = time.monotonic()-start
            count = data.get("usage", {}).get("completion_tokens")
            return {"text": content, "elapsed_seconds": round(elapsed, 3), "completion_tokens": count,
                    "tokens_per_second": round(count/elapsed, 2) if type(count) is int and count>0 else None,
                    "endpoint": "127.0.0.1:8081", "commands_executed": False, "model": self.config["model"]}
        except (OSError, ValueError, KeyError, IndexError, http.client.HTTPException):
            raise Blocked("LOCAL_AI unavailable or incompatible; core remains operational") from None
        finally:
            connection.close()
            MODEL_LOCK.release()


def benchmark(root):
    config = Vault(root).load("local_ai")
    result = LocalAI(config).generate("Ответь одним предложением: что такое очередь заданий?")
    result["hardware_scope"] = "This machine only; GPU/CUDA utilization requires separate nvidia-smi measurement"
    return result
