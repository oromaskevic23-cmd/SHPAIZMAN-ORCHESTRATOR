"""Local Ollama draft operation shared by the desktop and the Telegram controller."""
import hashlib
import http.client
import json

from .security import Blocked

OPERATION = "ai_draft"
MODELS = ("qwen2.5:0.5b", "qwen2.5:1.5b", "qwen2.5:3b", "qwen2.5:7b")


def prepare(model, prompt):
    if model not in MODELS:
        raise Blocked("Сначала выберите установленную локальную модель в SETTINGS.")
    if not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 4000:
        raise ValueError("Введите задание длиной от 1 до 4000 символов.")
    return {"model": model, "prompt": prompt.strip()}


def post_local(path, payload):
    connection = http.client.HTTPConnection("127.0.0.1", 11434, timeout=100)
    try:
        connection.request("POST", path, json.dumps(payload).encode(), {"Content-Type": "application/json"})
        response = connection.getresponse()
        raw = response.read(1_048_577)
        if response.status == 404:
            raise Blocked("Модель не найдена. Установите выбранную модель через ollama pull.")
        if response.status != 200 or len(raw) > 1_048_576:
            raise Blocked("Ollama отклонила запрос или превысила размер ответа.")
        body = json.loads(raw)
        if not isinstance(body, dict):
            raise ValueError("Invalid response")
        return body
    except (OSError, ValueError, http.client.HTTPException):
        raise Blocked("Локальная Ollama недоступна или вернула некорректный ответ.") from None
    finally:
        connection.close()


def generate(agent, payload):
    job = prepare(payload.get("model"), payload.get("prompt"))
    model_info = post_local("/api/show", {"name": job["model"]})
    details = model_info.get("details")
    if (model_info.get("remote_host") or model_info.get("remote_model") or
            not isinstance(details, dict) or details.get("format") != "gguf"):
        raise Blocked("Требуется установленная локальная модель GGUF.")
    system = (f"You are a {agent.profession}. Answer the user directly. "
              "Answer in the user's language. Do not claim to have taken external actions.")
    body = post_local("/api/chat", {"model": job["model"], "stream": False,
                      "messages": [{"role": "system", "content": system},
                                   {"role": "user", "content": job["prompt"]}],
                      "options": {"num_predict": 512, "temperature": 0}})
    message = body.get("message")
    output = message.get("content") if isinstance(message, dict) else None
    if (body.get("done") is not True or body.get("model") != job["model"] or
            not isinstance(output, str) or not output.strip() or len(output.encode()) > 48000):
        raise Blocked("Ollama не вернула завершённый текст для выбранной модели.")
    return {"mode": "LOCAL_MODEL", "agent_id": agent.id, "model": job["model"], "text": output,
            "response_sha256": hashlib.sha256(output.encode()).hexdigest(), "human_review_required": True}
