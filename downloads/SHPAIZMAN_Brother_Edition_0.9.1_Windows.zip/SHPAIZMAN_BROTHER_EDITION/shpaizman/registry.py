"""Static allowlisted module discovery; never imports paths supplied by tasks."""
from importlib import import_module

PLATFORMS = ("albato", "aimylogic", "tomoru", "twin", "gigachat", "yandex", "nodul", "bitrix24", "mws", "cloudru")


def discover():
    result = {}
    for platform in PLATFORMS:
        agent = import_module("shpaizman.agents." + platform).AGENT
        if agent.platform != platform or agent.id in [a.id for a in result.values()]:
            raise RuntimeError("Registry identity collision")
        result[platform] = agent
    return result


def route(value):
    agents = discover()
    matches = [a for a in agents.values() if value in (a.id, a.platform, a.profession)]
    if len(matches) != 1:
        raise ValueError("Unknown/ambiguous agent specialization")
    return matches[0]
