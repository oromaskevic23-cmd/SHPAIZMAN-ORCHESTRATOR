from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time
import tempfile
import unittest

from .legacy import default_db_path
from .orchestrator import Orchestrator
from .registry import discover


def main():
    parser = argparse.ArgumentParser(description="SHPAIZMAN Brother Edition")
    parser.add_argument("command", nargs="?", default="desktop", choices=("desktop", "status", "diagnostics", "self-test", "smoke", "gui-smoke", "local-ai-benchmark"))
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--network", action="store_true")
    args = parser.parse_args()
    if args.command in {"smoke", "gui-smoke"} and args.data_dir is None:
        with tempfile.TemporaryDirectory(prefix="shpaizman-check-") as tmp:
            args.data_dir = Path(tmp)
            return run(args)
    args.data_dir = args.data_dir or default_db_path().parent
    return run(args)


def run(args):
    if args.command == "self-test":
        suite = unittest.defaultTestLoader.discover(str(Path(__file__).resolve().parent.parent / "tests"))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        raise SystemExit(0 if result.wasSuccessful() else 1)
    if args.command == "local-ai-benchmark":
        from .local_ai import benchmark
        output = benchmark(args.data_dir)
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return
    with_app = Orchestrator(args.data_dir)
    try:
        if args.command in {"desktop", "gui-smoke"}:
            from .ui import Desktop
            ui = Desktop(with_app, wizard=args.command == "desktop")
            if args.command == "gui-smoke":
                ui.root.update()
                assert len(ui.agent_tree.get_children()) == 10
                ui.callbacks["START"]()
                assert with_app.mode == "RUNNING"
                ui.callbacks["PAUSE"]()
                assert with_app.mode == "PAUSED"
                ui.callbacks["STOP"]()
                assert with_app.mode == "STOPPED"
                ui.root.update()
                ui.close()
                output = {"gui": "PASS", "buttons": ["START", "PAUSE", "STOP"], "agent_rows": 10}
            else:
                ui.run()
                return
        elif args.command == "diagnostics":
            from .diagnostics import diagnose
            output = diagnose(with_app, args.network)
        elif args.command == "smoke":
            jobs = [with_app.submit(a.platform, a.operation, a.example) for a in discover().values()]
            with_app.start()
            deadline = time.monotonic()+90
            while time.monotonic() < deadline:
                statuses = [with_app.store.task(j)["state"] for j in jobs]
                if all(s == "SUCCEEDED_LOCAL" for s in statuses):
                    break
                if any(s in {"FAILED", "BLOCKED", "TIMED_OUT"} for s in statuses):
                    raise RuntimeError("Smoke task failed")
                time.sleep(0.1)
            else:
                raise RuntimeError("Smoke timeout: " + with_app.reason)
            output = {"smoke": "PASS", "agents_executed": 10, "states": statuses,
                      "resources": with_app.resources.snapshot(), "external_connections": 0}
        else:
            output = {"mode": with_app.mode, "agents": with_app.statuses(), "crm": with_app.store.summary()}
        encoded = json.dumps(output, ensure_ascii=False, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(encoded, encoding="utf-8")
        print(encoded)
    finally:
        with_app.close()
