"""Bind one dedicated bot to its owner's private chat, at the owner's computer."""
from getpass import getpass
from pathlib import Path
import os
import secrets
import sys
import time

from .legacy import default_db_path
from .security import Blocked, InstanceLock, RemoteFailure, Vault
from .store import Store
from .telegram import TelegramAPI


def match_owner(update, code, issued):
    if not isinstance(update, dict):
        return None
    msg = update.get("message")
    if not isinstance(msg, dict) or msg.get("text") != "/start " + code:
        return None
    sender, chat = msg.get("from"), msg.get("chat")
    if not isinstance(sender, dict) or not isinstance(chat, dict):
        return None
    if ("forward_origin" in msg or "forward_date" in msg or "sender_chat" in msg or
            type(msg.get("date")) is not int or not issued - 2 <= msg["date"] <= time.time() + 30 or
            chat.get("type") != "private" or type(chat.get("id")) is not int or
            type(sender.get("id")) is not int or sender.get("is_bot") is not False or
            sender["id"] != chat["id"] or sender["id"] <= 0):
        return None
    return sender["id"]


def pair(root):
    lock = InstanceLock(root / "application.lock")
    try:
        store, vault = Store(root), Vault(root)
        if vault.load("telegram") and input("Заменить сохранённую привязку? Введите ДА: ").strip() != "ДА":
            return 1
        token = getpass("Токен отдельного бота от BotFather (ввод скрыт): ").strip()
        # No sendMessage call is made during pairing.
        api = TelegramAPI({"token": token, "owner_id": 1})
        bot = api.check()
        code = secrets.token_hex(8)
        print(f"Откройте личный чат с @{bot['username']}. С телефона владельца отправьте:\n/start {code}", flush=True)
        issued = int(time.time())
        deadline = time.monotonic() + 180
        offset = 0
        while time.monotonic() < deadline:
            updates = api.updates(offset)
            if not isinstance(updates, list):
                raise Blocked("Некорректный ответ Telegram.")
            for update in updates:
                if not isinstance(update, dict) or type(update.get("update_id")) is not int:
                    continue
                offset = update["update_id"] + 1
                owner = match_owner(update, code, issued)
                if owner is None:
                    continue
                confirm = input(f"Привязать @{bot['username']} к личному ID {owner}? Введите ДА: ")
                if confirm.strip() != "ДА":
                    return 1
                # Save credentials last so a partial pairing cannot inherit the previous bot's authorization.
                for key, value in (("telegram_offset", offset), ("telegram_last_authorized", offset-1),
                                   ("telegram_update_at", time.time()), ("telegram_pending_reply", None),
                                   ("telegram_owner_verified_at", time.time()), ("telegram_bot_verified_at", time.time()),
                                   ("telegram_autostart", True)):
                    store.set_setting(key, value)
                vault.save("telegram", {"token": token, "owner_id": owner})
                print("Готово. Запустите START_SHPAIZMAN.cmd и отправьте /status.")
                return 0
        raise Blocked("Три минуты истекли. Закройте окно и начните привязку заново.")
    finally:
        lock.close()


def main():
    if os.name != "nt":
        print("Мастер привязки требует Windows и хранилище DPAPI.", file=sys.stderr)
        return 2
    try:
        return pair(Path(default_db_path()).parent)
    except (Blocked, RemoteFailure, ValueError, OSError, EOFError) as exc:
        print(str(exc) if isinstance(exc, (Blocked, RemoteFailure)) else "Привязка не завершена.", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
