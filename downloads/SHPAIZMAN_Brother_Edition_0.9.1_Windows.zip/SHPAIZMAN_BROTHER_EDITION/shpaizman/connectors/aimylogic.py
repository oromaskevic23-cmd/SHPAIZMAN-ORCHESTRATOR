import re
from .base import Connector, array
from ..security import Blocked, safe_token


class AimylogicConnector(Connector):
    operations = ("chat_test",)
    mutates = True

    def validate(self):
        super().validate()
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,300}", safe_token(self.config)):
            raise Blocked("Invalid Chat API token")
        if self.config.get("isolated_test_bot") is not True:
            raise Blocked("Use an isolated test bot without paid/external actions")

    def execute(self, operation, payload):
        self.validate()
        query = payload.get("query")
        if not isinstance(query, str) or not 1 <= len(query) <= 1000:
            raise ValueError("query must contain 1..1000 characters")
        value, receipt = self.transport.request("POST", "https://bot.jaicp.com/chatapi/" + safe_token(self.config), {},
                                               {"clientId": "shpaizman-local-test", "query": query}, hosts=("bot.jaicp.com",))
        replies = array(value.get("data", value) if isinstance(value, dict) else value, "replies")
        return self.result(operation, {"replies": [{"type": str(r.get("type", ""))[:30], "text": str(r.get("text", ""))[:2000]} for r in replies[:10] if isinstance(r, dict)]}, receipt)
