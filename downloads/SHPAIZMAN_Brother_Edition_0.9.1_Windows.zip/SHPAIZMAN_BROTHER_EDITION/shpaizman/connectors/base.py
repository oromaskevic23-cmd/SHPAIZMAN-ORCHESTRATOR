from ..security import Blocked, RemoteFailure, safe_token
from .transport import Transport


def array(value, key):
    if not isinstance(value, dict) or not isinstance(value.get(key), list):
        raise RemoteFailure("RESULT_SCHEMA_MISMATCH")
    return value[key]


class Connector:
    operations = ()
    blocked_reason = ""
    mutates = False

    def __init__(self, config=None, transport=None):
        self.config = config or {}
        self.transport = transport or Transport()

    def validate(self):
        if self.blocked_reason:
            raise Blocked(self.blocked_reason)
        safe_token(self.config)

    def execute(self, operation, payload):
        raise Blocked(self.blocked_reason or "Operation not implemented")

    def bearer(self):
        return {"Authorization": "Bearer " + safe_token(self.config)}

    def result(self, operation, data, receipt):
        if receipt.get("transport") != "REAL_HTTPS":
            raise RemoteFailure("REAL_TRANSPORT_REQUIRED")
        return {"mode": "REMOTE", "operation": operation, "data": data, "receipt": receipt}
