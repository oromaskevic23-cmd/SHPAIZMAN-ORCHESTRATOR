import re
from urllib.parse import urlencode
from .base import Connector, array
from ..security import Blocked, safe_token, RemoteFailure


class YandexConnector(Connector):
    operations = ("list_assistants",)

    def validate(self):
        super().validate()
        if not re.fullmatch(r"[A-Za-z0-9_-]{3,100}", self.config.get("folder_id", "")):
            raise Blocked("folder_id required")

    def execute(self, operation, payload):
        self.validate()
        url = "https://rest-assistant.api.cloud.yandex.net/assistants/v1/assistants?" + urlencode({"folderId": self.config["folder_id"], "pageSize": 20})
        value, receipt = self.transport.request("GET", url, {"Authorization": "Api-Key " + safe_token(self.config)}, hosts=("rest-assistant.api.cloud.yandex.net",))
        rows = array(value, "assistants")
        if any(not isinstance(r, dict) or not isinstance(r.get("id"), str) for r in rows):
            raise RemoteFailure("ASSISTANT_SCHEMA_MISMATCH")
        return self.result(operation, {"assistant_ids": [r["id"][:100] for r in rows[:20]]}, receipt)
