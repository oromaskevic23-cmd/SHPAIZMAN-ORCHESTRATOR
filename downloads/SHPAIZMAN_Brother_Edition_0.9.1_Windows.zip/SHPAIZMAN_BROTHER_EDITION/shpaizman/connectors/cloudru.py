from .base import Connector, array
from ..security import RemoteFailure


class CloudRuConnector(Connector):
    operations = ("list_models",)

    def execute(self, operation, payload):
        self.validate()
        value, receipt = self.transport.request("GET", "https://foundation-models.api.cloud.ru/v1/models", self.bearer(), hosts=("foundation-models.api.cloud.ru",))
        rows = array(value, "data")
        if any(not isinstance(r, dict) or not isinstance(r.get("id"), str) for r in rows):
            raise RemoteFailure("MODEL_SCHEMA_MISMATCH")
        return self.result(operation, {"models": [r["id"][:200] for r in rows[:100]]}, receipt)
