from .base import Connector
from ..security import RemoteFailure


class AlbatoConnector(Connector):
    operations = ("list_partners",)

    def execute(self, operation, payload):
        self.validate()
        value, receipt = self.transport.request("GET", "https://uapi.albato.com/partners/info?filter%5Bdeprecated%5D=0",
                                               self.bearer(), hosts=("uapi.albato.com",))
        rows = value if isinstance(value, list) else value.get("data", value.get("partners")) if isinstance(value, dict) else None
        if not isinstance(rows, list) or any(not isinstance(r, dict) or not (r.get("id") or r.get("partnerId")) for r in rows):
            raise RemoteFailure("ALBATO_RESULT_SCHEMA_MISMATCH")
        return self.result(operation, {"partner_count": len(rows), "ids": [str(r.get("id", r.get("partnerId")))[:100] for r in rows[:50]]}, receipt)
