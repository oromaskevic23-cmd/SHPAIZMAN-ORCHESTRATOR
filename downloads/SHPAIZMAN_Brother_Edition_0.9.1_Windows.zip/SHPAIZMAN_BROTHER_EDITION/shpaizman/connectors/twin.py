from .base import Connector, array


class TwinConnector(Connector):
    operations = ("list_messages",)

    def execute(self, operation, payload):
        self.validate()
        value, receipt = self.transport.request("GET", "https://notify.twin24.ai/api/v1/messages?limit=10",
                                               self.bearer(), hosts=("notify.twin24.ai",))
        rows = array(value, "items")
        return self.result(operation, {"message_count": len(rows), "statuses": [str(r.get("status", ""))[:40] for r in rows if isinstance(r, dict)]}, receipt)
