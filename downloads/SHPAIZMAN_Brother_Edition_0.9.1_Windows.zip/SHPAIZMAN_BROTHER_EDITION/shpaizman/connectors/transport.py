"""Bounded HTTPS, fixed destination policy, no redirects/proxy/TLS bypass."""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import json
import socket
import ssl
import time
from urllib.parse import urlsplit

from ..security import Blocked, RemoteFailure

MAX_RESPONSE = 512_000


def validate_url(url: str, hosts: tuple[str, ...], suffixes: tuple[str, ...] = ()):
    try:
        u = urlsplit(url)
        host = u.hostname or ""
        port = u.port
    except ValueError:
        raise Blocked("Malformed endpoint") from None
    if (u.scheme != "https" or port not in (None, 443) or u.username or u.password
            or u.fragment or "\\" in url or any(ord(c) < 33 for c in url)):
        raise Blocked("Only approved HTTPS endpoints on port 443 are allowed")
    if not (host in hosts or any(host.endswith("." + suffix) for suffix in suffixes)):
        raise Blocked("Endpoint host is outside platform allowlist")
    return u


class PinnedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, ip, timeout):
        super().__init__(host, timeout=timeout, context=ssl.create_default_context())
        self.ip = ip

    def connect(self):
        self.sock = socket.create_connection((self.ip, 443), self.timeout)
        self.sock = self._context.wrap_socket(self.sock, server_hostname=self.host)


class Transport:
    def request(self, method, url, headers, body=None, *, hosts=(), suffixes=(), timeout=10):
        if method not in {"GET", "POST"}:
            raise Blocked("HTTP method denied")
        u = validate_url(url, hosts, suffixes)
        start = time.monotonic()
        connection = None
        try:
            addresses = socket.getaddrinfo(u.hostname, 443, type=socket.SOCK_STREAM)
            if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
                raise Blocked("Private, loopback or reserved destination rejected")
            # Use the validated address, not a second DNS lookup (rebind protection).
            connection = PinnedHTTPS(u.hostname, addresses[0][4][0], timeout)
            payload = json.dumps(body, ensure_ascii=False, allow_nan=False).encode() if body is not None else None
            if payload and len(payload) > 32000:
                raise Blocked("Request body too large")
            all_headers = {"Accept": "application/json", "User-Agent": "SHPAIZMAN/0.9",
                           "Content-Type": "application/json", **headers}
            connection.request(method, u.path + ("?" + u.query if u.query else ""), payload, all_headers)
            response = connection.getresponse()
            if response.status != 200:
                raise RemoteFailure("HTTP_" + str(response.status), response.status in {429, 502, 503, 504})
            if "json" not in response.getheader("Content-Type", "").lower():
                raise RemoteFailure("NON_JSON_RESPONSE")
            raw = response.read(MAX_RESPONSE + 1)
            if len(raw) > MAX_RESPONSE:
                raise RemoteFailure("RESPONSE_TOO_LARGE")
            value = json.loads(raw)
            return value, {"http_status": 200, "response_sha256": hashlib.sha256(raw).hexdigest(),
                           "bytes": len(raw), "duration_ms": round((time.monotonic()-start)*1000),
                           "checked_at": time.time(), "host": u.hostname, "transport": "REAL_HTTPS"}
        except (Blocked, RemoteFailure):
            raise
        except ssl.SSLError:
            raise RemoteFailure("TLS_VERIFICATION_FAILED") from None
        except (TimeoutError, socket.timeout, OSError, http.client.HTTPException):
            raise RemoteFailure("NETWORK_UNAVAILABLE", True) from None
        except (ValueError, UnicodeError):
            raise RemoteFailure("MALFORMED_JSON") from None
        finally:
            if connection:
                connection.close()
