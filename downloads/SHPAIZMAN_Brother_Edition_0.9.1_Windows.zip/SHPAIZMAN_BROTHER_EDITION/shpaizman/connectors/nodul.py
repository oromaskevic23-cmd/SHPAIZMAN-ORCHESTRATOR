from urllib.parse import urlsplit
from .base import Connector
from .transport import validate_url
from ..security import Blocked, RemoteFailure


class NodulConnector(Connector):
    operations = ("run_workflow",)
    mutates = True

    def validate(self):
        url = self.config.get("webhook_url", "")
        u = validate_url(url, (), ("nodul.ru",))
        if u.query or u.path in {"", "/"} or self.config.get("isolated_free_workflow") is not True:
            raise Blocked("Use an isolated free Nodul workflow with a real completion response; URL queries are denied")

    def execute(self, operation, payload):
        self.validate()
        import secrets
        nonce = secrets.token_hex(16)
        value, receipt = self.transport.request("POST", self.config["webhook_url"], {},
                                               {"request_id": nonce, "input": payload}, suffixes=("nodul.ru",))
        # Owner's Webhook Response node must run AFTER all workflow steps.
        if not isinstance(value, dict) or value.get("request_id") != nonce or value.get("status") != "completed" or "result" not in value:
            raise RemoteFailure("WORKFLOW_COMPLETION_NOT_CONFIRMED")
        result = value["result"]
        import json
        if len(json.dumps(result, ensure_ascii=False).encode()) > 30000:
            raise RemoteFailure("WORKFLOW_RESULT_TOO_LARGE")
        return self.result(operation, {"result": result, "request_id": nonce}, receipt)
