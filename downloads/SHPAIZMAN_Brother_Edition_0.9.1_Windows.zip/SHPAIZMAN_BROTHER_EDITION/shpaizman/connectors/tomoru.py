from .base import Connector


class TomoruConnector(Connector):
    blocked_reason = "TOMORU: official authenticated API schema and zero-cost account entitlement not verified; obtain provider documentation"
