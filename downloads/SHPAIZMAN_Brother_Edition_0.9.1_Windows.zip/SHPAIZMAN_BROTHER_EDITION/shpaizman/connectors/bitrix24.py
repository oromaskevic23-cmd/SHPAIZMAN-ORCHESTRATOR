import re
from .base import Connector
from .transport import validate_url
from ..security import Blocked, RemoteFailure


class BitrixConnector(Connector):
    operations = ("read_profile", "list_leads")

    def validate(self):
        u = validate_url(self.config.get("webhook_url", ""), (), ("bitrix24.ru", "bitrix24.com"))
        if u.query or not re.fullmatch(r"/rest/[0-9]+/[A-Za-z0-9_-]{8,200}/", u.path):
            raise Blocked("Provide the exact inbound webhook base ending with /rest/user/key/")

    def execute(self, operation, payload):
        self.validate()
        endpoint = "profile.json" if operation == "read_profile" else "crm.lead.list.json?select%5B%5D=ID&select%5B%5D=STATUS_ID&start=0"
        value, receipt = self.transport.request("GET", self.config["webhook_url"] + endpoint, {}, suffixes=("bitrix24.ru", "bitrix24.com"))
        if not isinstance(value, dict) or "error" in value or "result" not in value:
            raise RemoteFailure("BITRIX_APPLICATION_ERROR")
        result = value["result"]
        if operation == "read_profile":
            if not isinstance(result, dict) or not str(result.get("ID", "")).isdigit():
                raise RemoteFailure("BITRIX_PROFILE_SCHEMA_MISMATCH")
            output = {"account_id": str(result["ID"])}
        else:
            if not isinstance(result, list) or any(not isinstance(r, dict) or not str(r.get("ID", "")).isdigit() for r in result):
                raise RemoteFailure("BITRIX_LEADS_SCHEMA_MISMATCH")
            output = {"leads": [{"id": str(r["ID"]), "stage": str(r.get("STATUS_ID", ""))[:100]} for r in result[:50]], "first_page_only": True}
        return self.result(operation, output, receipt)
