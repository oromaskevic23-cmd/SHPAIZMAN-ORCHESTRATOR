from .base import Connector


class MWSConnector(Connector):
    blocked_reason = "MWS AI Agents: installation-specific API, license and free entitlement are unverified; GPT Model Hub is a different product and is not substituted"
