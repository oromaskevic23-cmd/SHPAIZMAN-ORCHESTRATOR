"""Measured resource admission for two bounded integration workers."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import shutil
import threading
import time

GIB = 1024 ** 3
_CHILD_PATHS = {}


def memory():
    if os.name == "nt":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [("length", wintypes.DWORD), ("load", wintypes.DWORD)] + [(n, ctypes.c_ulonglong) for n in
                ("total", "available", "total_page", "available_page", "total_virtual", "available_virtual", "extended")]
        m = MemoryStatus()
        m.length = ctypes.sizeof(m)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return {"total": None, "available": None}
        return {"total": m.total, "available": m.available}
    try:
        values = {line.split(":")[0]: int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines()}
        total, available = values["MemTotal"], values["MemAvailable"]
        cg = Path("/sys/fs/cgroup")
        if (cg / "memory.max").exists() and (cg / "memory.max").read_text().strip().isdigit():
            cap, used = int((cg/"memory.max").read_text()), int((cg/"memory.current").read_text())
            total, available = min(total, cap), min(available, max(0, cap-used))
        return {"total": total, "available": available}
    except (OSError, ValueError, KeyError):
        return {"total": None, "available": None}


def process_metrics(pid=None):
    pid = pid or os.getpid()
    if os.name == "nt":
        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("faults", wintypes.DWORD)] + [(name, ctypes.c_size_t) for name in
                ("peak_rss", "rss", "peak_paged", "paged", "peak_nonpaged", "nonpaged", "pagefile", "peak_pagefile")]
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        ps = ctypes.WinDLL("psapi", use_last_error=True)
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.OpenProcess.restype = wintypes.HANDLE
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        ps.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        k.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        handle = k.OpenProcess(0x0400 | 0x0010, False, pid)
        if not handle:
            return {"pid": pid, "rss_bytes": None, "cpu_seconds": None}
        try:
            c = Counters()
            c.cb = ctypes.sizeof(c)
            ok = ps.GetProcessMemoryInfo(handle, ctypes.byref(c), c.cb)
            times = [wintypes.FILETIME() for _ in range(4)]
            measured = k.GetProcessTimes(handle, *[ctypes.byref(t) for t in times])
            cpu = sum((t.dwHighDateTime << 32) + t.dwLowDateTime for t in times[2:]) / 10_000_000 if measured else None
            return {"pid": pid, "rss_bytes": c.rss if ok else None, "cpu_seconds": cpu}
        finally:
            k.CloseHandle(handle)
    try:
        proc_root = Path("/proc/self")
        if pid != os.getpid():
            # /proc may be mounted from the outer PID namespace (as in CI).
            outer_pid = next(s.split()[1] for s in (proc_root/"status").read_text().splitlines() if s.startswith("Pid:"))
            children = set()
            for thread in (proc_root/"task").iterdir():
                try:
                    children.update((thread/"children").read_text().split())
                except OSError:
                    pass
            cache_key = (outer_pid, pid)
            if cache_key in _CHILD_PATHS:
                children.add(_CHILD_PATHS[cache_key])
            if not children:
                # CONFIG_CHECKPOINT_RESTORE may disable /proc/.../children.
                children = {p.name for p in Path("/proc").iterdir() if p.name.isdigit()}
            found = None
            for candidate in children:
                path = Path("/proc")/candidate
                try:
                    info = (path/"status").read_text()
                    ns_pid = next(int(s.split()[-1]) for s in info.splitlines() if s.startswith("NSpid:"))
                    parent = next(s.split()[1] for s in info.splitlines() if s.startswith("PPid:"))
                    if ns_pid == pid and parent == outer_pid:
                        found = path
                        if len(_CHILD_PATHS) > 128:
                            _CHILD_PATHS.clear()
                        _CHILD_PATHS[cache_key] = candidate
                        break
                except (OSError, StopIteration):
                    continue
            if found is None:
                return {"pid": pid, "rss_bytes": None, "cpu_seconds": None}
            proc_root = found
        status = (proc_root/"status").read_text()
        rss = next(int(s.split()[1])*1024 for s in status.splitlines() if s.startswith("VmRSS:"))
        stat = (proc_root/"stat").read_text().rsplit(")", 1)[1].split()
        cpu = (int(stat[11]) + int(stat[12])) / os.sysconf("SC_CLK_TCK")
        return {"pid": pid, "rss_bytes": rss, "cpu_seconds": cpu}
    except (OSError, ValueError, StopIteration, IndexError):
        return {"pid": pid, "rss_bytes": None, "cpu_seconds": None}


class ResourceManager:
    max_workers = 2
    minimum_available = 2 * GIB
    maximum_process_tree_rss = 2 * GIB

    def __init__(self, root):
        self.root = root
        self.last = None
        self.guard = threading.Lock()

    def snapshot(self, pids=()):
        procs = [process_metrics(p) for p in (os.getpid(), *pids)]
        now = time.monotonic()
        cpu = sum(p["cpu_seconds"] or 0 for p in procs)
        pct = None
        # Comparable PID sets only; completed child CPU is recorded in task receipts.
        identity = tuple(p["pid"] for p in procs)
        with self.guard:
            if self.last and self.last[2] == identity:
                if now-self.last[0] >= 0.25:
                    pct = max(0, 100 * (cpu-self.last[1]) / (now-self.last[0]))
                    self.last = (now, cpu, identity)
            else:
                self.last = (now, cpu, identity)
        return {"memory": memory(), "processes": procs, "rss_bytes": sum(p["rss_bytes"] or 0 for p in procs),
                "cpu_percent_one_core": round(pct, 2) if pct is not None else None,
                "cpu_seconds_current_processes": cpu, "disk_free_bytes": shutil.disk_usage(self.root).free,
                "gpu_used_by_core": False, "worker_limit": self.max_workers,
                "all_processes_measured": all(p["rss_bytes"] is not None for p in procs)}

    def admit(self, pids=()):
        snapshot = self.snapshot(pids)
        available = snapshot["memory"]["available"]
        if not snapshot["all_processes_measured"]:
            return False, "Process memory measurement unavailable"
        if available is None:
            return False, "RAM measurement unavailable"
        if available < self.minimum_available:
            return False, "Less than 2 GiB available RAM"
        if snapshot["rss_bytes"] >= self.maximum_process_tree_rss:
            return False, "Application process memory exceeds 2 GiB"
        if snapshot["disk_free_bytes"] < 512 * 1024**2:
            return False, "Less than 512 MiB free disk"
        return True, "READY"
