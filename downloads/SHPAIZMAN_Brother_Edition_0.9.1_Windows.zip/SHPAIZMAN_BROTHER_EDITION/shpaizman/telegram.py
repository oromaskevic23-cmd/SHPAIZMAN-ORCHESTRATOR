"""Owner-only Bot API bridge evolved from the recovered Telegram controller."""
from __future__ import annotations

import json
import re
import threading
import time

from .connectors.transport import Transport
from .ai_draft import OPERATION
from .security import Blocked, RemoteFailure

HELP = ("Шпайзман • личный кабинет\n/status — состояние очереди\n/agents — исполнители\n"
        "/ask bitrix24 ваш вопрос — задание локальной модели\n"
        "/task <площадка> <операция> <JSON> — структурированное задание\n"
        "/jobs /errors /crm\n/result <id> [страница] — результат\n"
        "/cancel <id> /resume /pause /stop\nВнешние операции подтверждаются на ПК.")


def validate_config(config):
    if type(config.get("owner_id")) is not int or config["owner_id"] <= 0:
        raise Blocked("Telegram owner ID must be a positive integer")
    if not isinstance(config.get("token"), str) or not re.fullmatch(r"[0-9]{5,20}:[A-Za-z0-9_-]{20,100}", config["token"]):
        raise Blocked("Invalid Telegram token format")


class TelegramAPI:
    def __init__(self, config):
        validate_config(config)
        self.token = config["token"]
        self.owner_id = config["owner_id"]
        self.transport = Transport()

    def call(self, method, payload):
        if method not in {"getMe", "getWebhookInfo", "getUpdates", "sendMessage"}:
            raise Blocked("Telegram method denied")
        if method == "sendMessage" and payload.get("chat_id") != self.owner_id:
            raise Blocked("Recipient is not the configured owner")
        value, receipt = self.transport.request("POST", "https://api.telegram.org/bot"+self.token+"/"+method,
                                               {}, payload, hosts=("api.telegram.org",), timeout=10)
        if not isinstance(value, dict) or value.get("ok") is not True or "result" not in value:
            raise RemoteFailure("TELEGRAM_APPLICATION_ERROR")
        return value["result"]

    def check(self):
        bot = self.call("getMe", {})
        if not isinstance(bot, dict) or bot.get("is_bot") is not True or type(bot.get("id")) is not int:
            raise RemoteFailure("TELEGRAM_BOT_SCHEMA_MISMATCH")
        info = self.call("getWebhookInfo", {})
        if not isinstance(info, dict) or info.get("url") != "":
            raise Blocked("У бота уже настроен webhook или его статус неизвестен. Выберите отдельного бота.")
        return {"status": "BOT_TOKEN_VERIFIED", "bot_id": bot["id"],
                "username": bot.get("username", ""), "owner_verified": False}

    def updates(self, offset):
        return self.call("getUpdates", {"offset": offset, "timeout": 3, "limit": 20, "allowed_updates": ["message"]})

    def reply(self, value):
        return self.call("sendMessage", {"chat_id": self.owner_id, "text": value[:3500]})


class TelegramController:
    def __init__(self, orchestrator, owner_id):
        if type(owner_id) is not int or owner_id <= 0:
            raise ValueError("Invalid Telegram owner")
        self.app, self.owner_id = orchestrator, owner_id
        self.window = []

    def handle(self, update):
        if not isinstance(update, dict) or type(update.get("update_id")) is not int or update["update_id"] < 0:
            return None
        msg = update.get("message")
        if not isinstance(msg, dict):
            return None
        user, chat = msg.get("from"), msg.get("chat")
        if not isinstance(user, dict) or not isinstance(chat, dict):
            return None
        if (type(user.get("id")) is not int or user.get("id") != self.owner_id or user.get("is_bot") is True
                or type(chat.get("id")) is not int or chat.get("id") != self.owner_id or chat.get("type") != "private"
                or "forward_origin" in msg or "forward_date" in msg or "sender_chat" in msg):
            return None
        age = time.time() - msg.get("date", 0) if type(msg.get("date")) is int else 10**10
        if not -30 <= age <= 120:
            return None
        content = msg.get("text")
        if not isinstance(content, str) or not content.startswith("/") or len(content) > 6000:
            return None
        last_seen = self.app.store.get_setting("telegram_owner_verified_at") or 0
        if (time.time() - last_seen < 6 * 86400
                and update["update_id"] <= self.app.store.get_setting("telegram_last_authorized", -1)):
            return None
        # Durable at-most-once commands: crash may lose a command, never replay it.
        self.app.store.set_setting("telegram_last_authorized", update["update_id"])
        self.window = [t for t in self.window if time.monotonic()-t < 60]
        if len(self.window) >= 20 and content.strip().lower() != "/stop":
            return "Rate limit: 20 owner commands/minute"
        self.window.append(time.monotonic())
        self.app.store.set_setting("telegram_owner_verified_at", time.time())
        parts = content.strip().split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) == 2 else ""
        try:
            if cmd in {"/start", "/help"}:
                return HELP
            if cmd == "/status":
                return self.app.mode + " | " + self.app.reason
            if cmd == "/agents":
                return "\n".join(f"{r['id']} {r['platform']}: {r['module']} / {r['connection']}" for r in self.app.statuses())
            if cmd in {"/jobs", "/errors"}:
                tasks = self.app.store.tasks()
                if cmd == "/errors":
                    tasks = [t for t in tasks if t["state"] in {"FAILED", "BLOCKED", "TIMED_OUT", "INTERRUPTED"}]
                return "\n".join(f"{t['id']} {t['platform']} {t['state']}" for t in tasks[:10]) or "No tasks"
            if cmd == "/crm":
                return json.dumps(self.app.store.summary(), ensure_ascii=False)
            if cmd == "/ask":
                platform, prompt = arg.split(maxsplit=1)
                job = self.app.submit(platform.lower(), OPERATION, {"prompt": prompt})
                return "Задание принято. Для обработки включите /resume.\n/result " + job
            if cmd == "/task":
                platform, operation, payload = arg.split(maxsplit=2)
                job = self.app.submit(platform, operation, json.loads(payload))
                return "Queued: " + job
            if cmd in {"/result", "/cancel"}:
                args = arg.split()
                if not args or len(args) > (2 if cmd == "/result" else 1):
                    raise ValueError("Invalid parameters")
                arg = args[0]
                if not re.fullmatch(r"[0-9a-f]{32}", arg):
                    raise ValueError("Invalid task id")
                if cmd == "/cancel":
                    return "Cancelled" if self.app.cancel(arg) else "Not cancellable"
                task = self.app.store.task(arg)
                if not task:
                    return "Not found"
                page = int(args[1]) if len(args) == 2 else 1
                result = json.loads(task["result"]) if task["result"] else {}
                body = result.get("text") if result.get("mode") == "LOCAL_MODEL" else None
                body = body or (json.dumps(result, ensure_ascii=False, indent=2) if result else "Результат ожидается.")
                # 1550 Unicode code points fit Telegram even with supplementary characters.
                pages = (len(body) + 1549) // 1550
                if not 1 <= page <= pages:
                    return f"Страницы: 1–{pages}"
                suffix = f"\n/result {arg} {page+1}" if page < pages else ""
                return f"{task['state']} · {page}/{pages}\n" + body[(page-1)*1550:page*1550] + suffix
            if cmd == "/stop":
                self.app.stop()
                return "STOPPED: queued/active execution cancelled; already sent external operations cannot be undone"
            if cmd == "/pause":
                self.app.pause()
                return "PAUSED: active tasks may finish"
            if cmd == "/resume":
                self.app.start()
                return "RUNNING"
            return "Unknown command. /help"
        except Blocked as exc:
            return str(exc)
        except (ValueError, TypeError, KeyError):
            return "Command rejected; use /help and local CRM diagnostics"


class TelegramService:
    def __init__(self, orchestrator, config):
        self.app = orchestrator
        self.api = TelegramAPI(config)
        self.controller = TelegramController(orchestrator, config["owner_id"])
        self.shutdown = threading.Event()
        self.thread = None
        self.status = "OFFLINE"

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._loop, daemon=True, name="SHPAIZMAN-Telegram")
        self.thread.start()

    def _loop(self):
        offset = self.app.store.get_setting("telegram_offset", 0)
        last_update = self.app.store.get_setting("telegram_update_at") or 0
        delay = 1
        while not self.shutdown.is_set():
            try:
                if self.status != "CONNECTED":
                    self.bot_id = self.api.check()["bot_id"]
                    self.app.store.set_setting("telegram_bot_verified_at", time.time())
                    self.status = "CONNECTED"
                if time.time() - last_update >= 6 * 86400:
                    offset = 0
                pending = self.app.store.get_setting("telegram_pending_reply")
                if pending and pending.get("owner") == self.api.owner_id and pending.get("bot") == self.bot_id:
                    self.api.reply(pending["text"])
                    self.app.store.set_setting("telegram_pending_reply", None)
                updates = self.api.updates(offset)
                if not isinstance(updates, list):
                    raise ValueError("Malformed updates")
                for update in updates:
                    if self.shutdown.is_set():
                        break
                    if not isinstance(update, dict) or type(update.get("update_id")) is not int:
                        continue
                    answer = self.controller.handle(update)
                    offset = max(offset, update["update_id"] + 1)
                    last_update = time.time()
                    self.app.store.set_setting("telegram_update_at", last_update)
                    if answer:
                        self.app.store.set_setting("telegram_pending_reply",
                                                   {"bot": self.bot_id, "owner": self.api.owner_id, "text": answer})
                    self.app.store.set_setting("telegram_offset", offset)
                    if answer:
                        self.api.reply(answer)
                        self.app.store.set_setting("telegram_pending_reply", None)
                delay = 1
                self.shutdown.wait(0.3)
            except (Blocked, RemoteFailure) as exc:
                self.status = "ERROR: " + str(exc)
                self.shutdown.wait(delay)
                delay = min(30, delay*2)
            except Exception:
                self.status = "ERROR"
                self.shutdown.wait(delay)
                delay = min(30, delay*2)
        self.status = "OFFLINE"

    def close(self):
        self.shutdown.set()
        if self.thread:
            self.thread.join(12)
            if self.thread.is_alive():
                raise Blocked("Telegram request is still closing; wait before restore/exit")
