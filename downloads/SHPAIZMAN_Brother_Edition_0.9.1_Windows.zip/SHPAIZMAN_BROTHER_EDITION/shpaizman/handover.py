"""Deterministic, no-side-effects handoff contract for the brother's own Astra.

It is an execution PLAN; it does not silently take control of a Windows computer.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from .registry import discover


def build_handover(root: Path) -> dict:
    root = Path(root).resolve()
    agents = discover()
    expected = ("albato", "aimylogic", "tomoru", "twin", "gigachat",
                "yandex", "nodul", "bitrix24", "mws", "cloudru")
    if tuple(agents) != expected or len({a.id for a in agents.values()}) != 10:
        raise RuntimeError("TEN_AGENT_REGISTRY_MISMATCH")
    stages = [
        {"id": "01_VERIFY", "action": "Run the package SHA256SUMS verification and local unit suite",
         "approval_required": False, "command": "py -3.12 scripts/verify_manifest.py"},
        {"id": "02_PREFLIGHT", "action": "Read-only Windows architecture, Python and disk inventory",
         "approval_required": False, "command": "powershell -NoProfile -File scripts/preflight.ps1"},
        {"id": "03_INSTALL", "action": "Install only into new per-user folder, never overwrite or elevate",
         "approval_required": True, "command": "INSTALL.cmd"},
        {"id": "04_SMOKE", "action": "Run ten local offline agent self-checks",
         "approval_required": True, "command": "py -3.12 run.py smoke"},
        {"id": "05_ACCOUNTS", "action": "Ask brother to authenticate each authorized platform directly",
         "approval_required": True, "command": None},
        {"id": "06_FINANCE", "action": "Configure public MetaMask destination only after ownership check",
         "approval_required": True, "command": None},
        {"id": "07_EXTERNAL", "action": "Enable bounded external jobs only after service-specific grants",
         "approval_required": True, "command": None}
    ]
    return {"schema": "shpaizman_astra_handover_v1", "beneficiary": "Alexander Viktorovich",
            "owner_control": "BROTHER_APPROVAL_REQUIRED", "platform_agents": [
                {"agent_id": a.id, "platform": p, "profession": a.profession,
                 "external_connection": "UNVERIFIED", "payout": "NOT_CONFIGURED"}
                for p, a in agents.items()],
            "stages": stages, "permissions": {
                "shell_arbitrary_commands": False, "admin_elevation": False,
                "antivirus_changes": False, "automatic_wallet_transfer": False,
                "credential_export": False, "purchases": False,
                "remote_login_without_brother_approval": False},
            "repository_distribution": "SOURCE_AUDIT_AND_REPRODUCIBLE_INSTALL_KIT",
            "guaranteed_income": False,
            "notes": "Brother Astra must be installed and authorized on his own computer."}


def write_handover(root: Path, output: Path) -> dict:
    data = build_handover(root)
    output = Path(output)
    if output.exists():
        raise FileExistsError("Handover report already exists; refuse silent overwrite")
    output.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    output.write_text(raw, encoding="utf-8")
    return {"status": "PLAN_ONLY", "sha256": hashlib.sha256(raw.encode()).hexdigest(),
            "path": str(output), "external_accounts_verified": 0,
            "brother_wallet_connected": False}
