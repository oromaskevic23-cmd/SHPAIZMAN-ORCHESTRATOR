"""Transactional queue/CRM built on the recovered SHPAIZMAN SQLite schema."""
from __future__ import annotations

from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import time
from uuid import uuid4

from .legacy import Shpaizman as RecoveredShpaizman, open_db, record, utc_now, validate_text
from .security import Blocked, private_directory, validate_grant

STATES = {"QUEUED", "RUNNING", "RETRY_WAIT", "SUCCEEDED_LOCAL", "SUCCEEDED_REMOTE",
          "FAILED", "BLOCKED", "CANCELLED", "TIMED_OUT", "INTERRUPTED"}
TRANSITIONS = {
    "QUEUED": {"RUNNING", "CANCELLED", "BLOCKED"},
    "RETRY_WAIT": {"RUNNING", "CANCELLED", "BLOCKED"},
    "RUNNING": {"SUCCEEDED_LOCAL", "SUCCEEDED_REMOTE", "FAILED", "BLOCKED", "CANCELLED",
                "TIMED_OUT", "INTERRUPTED", "RETRY_WAIT"},
}


def canonical(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


class Store(RecoveredShpaizman):
    def __init__(self, root: Path):
        self.root = Path(root)
        private_directory(self.root)
        super().__init__(self.root / "shpaizman.sqlite3")
        with open_db(self.db_path) as db:
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version > 6:
                raise Blocked("Database belongs to a newer application")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS work_items(
                  id TEXT PRIMARY KEY, platform TEXT NOT NULL, operation TEXT NOT NULL,
                  payload TEXT NOT NULL, digest TEXT NOT NULL, state TEXT NOT NULL,
                  result TEXT, attempts INTEGER NOT NULL DEFAULT 0,
                  created REAL NOT NULL, updated REAL NOT NULL, not_before REAL NOT NULL DEFAULT 0,
                  timeout INTEGER NOT NULL DEFAULT 30, approved_until REAL NOT NULL DEFAULT 0,
                  approval_digest TEXT NOT NULL DEFAULT '', remote INTEGER NOT NULL DEFAULT 0);
                CREATE INDEX IF NOT EXISTS work_state ON work_items(state,created);
                CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS connections(platform TEXT PRIMARY KEY,status TEXT NOT NULL,
                  checked REAL NOT NULL, config_hash TEXT NOT NULL, receipt TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS grants_used(grant_hash TEXT PRIMARY KEY,calls INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,
                  deal_id TEXT NOT NULL REFERENCES deals(id), kopecks INTEGER NOT NULL CHECK(kopecks>0),
                  reference TEXT NOT NULL UNIQUE, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS agent_enabled(platform TEXT PRIMARY KEY,enabled INTEGER NOT NULL);
                PRAGMA user_version=6;
            """)
            # Legacy jobs are retained, not silently executed or falsely relabelled.
            record(db, "STORE_OPEN", "schema-6")
        self.maintain()

    def get_setting(self, key, default=None):
        with open_db(self.db_path) as db:
            r = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            return json.loads(r[0]) if r else default

    def set_setting(self, key, value):
        with open_db(self.db_path) as db:
            db.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, canonical(value)))

    def enqueue_task(self, platform: str, operation: str, payload: dict, remote=False, timeout=30) -> str:
        if type(timeout) is not int or not 1 <= timeout <= 120:
            raise ValueError("Timeout must be 1..120 seconds")
        data = canonical(payload)
        if not isinstance(payload, dict) or len(data.encode()) > 16000:
            raise ValueError("Task must be a JSON object up to 16000 bytes")
        digest = hashlib.sha256(canonical([platform, operation, payload]).encode()).hexdigest()
        now, job = time.time(), uuid4().hex
        with open_db(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT COUNT(*) FROM work_items WHERE state IN ('QUEUED','RUNNING','RETRY_WAIT')").fetchone()[0] >= 100:
                raise ValueError("Queue full (100)")
            if db.execute("SELECT COUNT(*) FROM work_items").fetchone()[0] >= 5000:
                raise Blocked("Task history capacity reached; export and archive completed work")
            db.execute("INSERT INTO work_items(id,platform,operation,payload,digest,state,created,updated,timeout,remote) "
                       "VALUES (?,?,?,?,?,'QUEUED',?,?,?,?)", (job, platform, operation, data, digest, now, now, timeout, int(remote)))
            record(db, "TASK_QUEUED", job)
            db.commit()
        return job

    def task(self, job):
        with open_db(self.db_path) as db:
            row = db.execute("SELECT * FROM work_items WHERE id=?", (job,)).fetchone()
            return dict(row) if row else None

    def tasks(self, limit=200):
        if type(limit) is not int or not 1 <= limit <= 5000:
            raise ValueError("Invalid limit")
        with open_db(self.db_path) as db:
            return [dict(r) for r in db.execute("SELECT * FROM work_items ORDER BY created DESC,rowid DESC LIMIT ?", (limit,))]

    def approve(self, job):
        with open_db(self.db_path) as db:
            db.execute("UPDATE work_items SET approved_until=?,approval_digest=digest WHERE id=? AND state='QUEUED'",
                       (time.time() + 600, job))
            record(db, "TASK_APPROVED_LOCALLY_10M", job)

    def transition(self, job, state, result=None, not_before=0):
        if state not in STATES:
            raise ValueError("Unknown state")
        encoded = canonical(result) if result is not None else None
        if encoded and len(encoded.encode()) > 65536:
            raise ValueError("Result exceeds 64 KiB")
        with open_db(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            r = db.execute("SELECT state FROM work_items WHERE id=?", (job,)).fetchone()
            if not r or state not in TRANSITIONS.get(r[0], set()):
                db.rollback()
                return False
            db.execute("UPDATE work_items SET state=?,result=?,updated=?,not_before=? WHERE id=?",
                       (state, encoded, time.time(), not_before, job))
            record(db, "TASK_" + state, job)
            db.commit()
            return True

    def claim(self, busy_platforms=()):
        with open_db(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            rows = db.execute("SELECT w.* FROM work_items w LEFT JOIN agent_enabled a ON a.platform=w.platform "
                              "WHERE state IN ('QUEUED','RETRY_WAIT') AND not_before<=? AND COALESCE(a.enabled,1)=1 "
                              "AND (remote=0 OR (approved_until>? AND approval_digest=digest)) "
                              "ORDER BY w.created,w.rowid LIMIT 100", (time.time(),time.time())).fetchall()
            r = next((r for r in rows if r["platform"] not in busy_platforms), None)
            if r is None:
                db.rollback()
                return None
            db.execute("UPDATE work_items SET state='RUNNING',attempts=attempts+1,updated=? WHERE id=?", (time.time(), r["id"]))
            record(db, "TASK_RUNNING", r["id"])
            db.commit()
            return self.task(r["id"])

    def recover(self):
        with open_db(self.db_path) as db:
            rows = db.execute("SELECT id FROM work_items WHERE state='RUNNING'").fetchall()
        for r in rows:
            self.transition(r[0], "INTERRUPTED", {"reason": "Process ended; external effects may be unknown; no automatic replay"})

    def reserve_request(self, platform, operation, config):
        validate_grant(config, operation)
        digest = hashlib.sha256(canonical([platform, config]).encode()).hexdigest()
        with open_db(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT OR IGNORE INTO grants_used VALUES (?,0)", (digest,))
            n = db.execute("SELECT calls FROM grants_used WHERE grant_hash=?", (digest,)).fetchone()[0]
            if n >= config["free_access"]["max_requests"]:
                raise Blocked("FREE_ONLY request allowance exhausted")
            db.execute("UPDATE grants_used SET calls=calls+1 WHERE grant_hash=?", (digest,))
            db.commit()

    def connection(self, platform, config):
        with open_db(self.db_path) as db:
            r = db.execute("SELECT * FROM connections WHERE platform=?", (platform,)).fetchone()
        if r and r["config_hash"] == self.config_hash(config) and time.time() - r["checked"] < 900:
            return r["status"]
        return "NOT_CONNECTED"

    @staticmethod
    def config_hash(config):
        return hashlib.sha256(canonical(config).encode()).hexdigest()

    def mark_connection(self, platform, config, status, receipt):
        with open_db(self.db_path) as db:
            db.execute("INSERT OR REPLACE INTO connections VALUES (?,?,?,?,?)",
                       (platform, status, time.time(), self.config_hash(config), canonical(receipt)))

    def enable_agent(self, platform, enabled):
        with open_db(self.db_path) as db:
            db.execute("INSERT OR REPLACE INTO agent_enabled VALUES (?,?)", (platform, int(enabled)))

    def agent_enabled(self, platform):
        with open_db(self.db_path) as db:
            r = db.execute("SELECT enabled FROM agent_enabled WHERE platform=?", (platform,)).fetchone()
            return not r or bool(r[0])

    def add_client(self, name, note=""):
        with open_db(self.db_path) as db:
            if db.execute("SELECT COUNT(*) FROM clients").fetchone()[0] >= 5000:
                raise Blocked("Client capacity reached")
        return super().add_client(name, note)

    def update_client(self, client_id, name, note=""):
        name = validate_text(name, "Name", 120)
        if not isinstance(note, str) or len(note) > 1200:
            raise ValueError("Note too long")
        with open_db(self.db_path) as db:
            db.execute("UPDATE clients SET name=?,note=? WHERE id=?", (name, note, client_id))
            record(db, "CLIENT_UPDATED", client_id)

    def set_deal_stage(self, deal, stage):
        if stage not in {"lead", "qualified", "in_progress", "delivered", "closed", "lost"}:
            raise ValueError("Invalid deal stage")
        with open_db(self.db_path) as db:
            db.execute("UPDATE deals SET status=? WHERE id=?", (stage, deal))
            record(db, "DEAL_STAGE_" + stage.upper(), deal)

    def record_payment(self, deal, kopecks, reference):
        if type(kopecks) is not int or not 1 <= kopecks <= 10**12:
            raise ValueError("Payment must be a positive integer number of kopecks")
        reference = validate_text(reference, "Receipt reference", 160)
        with open_db(self.db_path) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO payments VALUES (?,?,?,?,?)", (uuid4().hex, deal, kopecks, reference, utc_now()))
            record(db, "PAYMENT_RECORDED_BY_OWNER", deal)
            db.commit()

    def summary(self):
        with open_db(self.db_path) as db:
            return {"tasks": db.execute("SELECT COUNT(*) FROM work_items").fetchone()[0],
                    "clients": db.execute("SELECT COUNT(*) FROM clients").fetchone()[0],
                    "deals": db.execute("SELECT COUNT(*) FROM deals").fetchone()[0],
                    "income_kopecks_owner_recorded": db.execute("SELECT COALESCE(SUM(kopecks),0) FROM payments").fetchone()[0]}

    def maintain(self):
        with open_db(self.db_path) as db:
            db.execute("PRAGMA max_page_count=32768")
            db.execute("PRAGMA journal_size_limit=8388608")
            db.execute("DELETE FROM audit WHERE id NOT IN (SELECT id FROM audit ORDER BY id DESC LIMIT 10000)")
            db.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    def backup(self) -> Path:
        root = self.root / "backups"
        private_directory(root)
        destination = root / ("backup-" + str(time.time_ns()) + ".sqlite3")
        with open_db(self.db_path) as src, closing(sqlite3.connect(destination)) as dst:
            src.backup(dst)
            if dst.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise Blocked("Backup integrity check failed")
        for old in sorted(root.glob("backup-*.sqlite3"))[:-7]:
            old.unlink()
        return destination

    def restore(self, source: Path):
        # Called only with all workers/Telegram stopped by the owning application.
        source = Path(source).resolve()
        if source == self.db_path.resolve() or source.stat().st_size > 134217728:
            raise ValueError("Invalid backup")
        with closing(sqlite3.connect(source.as_uri() + "?mode=ro", uri=True)) as src:
            if src.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("Corrupt backup")
            if src.execute("PRAGMA user_version").fetchone()[0] != 6:
                raise ValueError("Unsupported backup schema")
            expected = {"work_items", "settings", "connections", "grants_used", "payments", "agent_enabled", "clients", "deals", "audit", "jobs"}
            tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not expected <= tables or src.execute("SELECT COUNT(*) FROM sqlite_master WHERE type IN ('trigger','view')").fetchone()[0]:
                raise ValueError("Unsupported backup objects")
            # Validate all consumed columns before replacing the live database.
            with open_db(self.db_path) as current:
                for name in expected:
                    a = [tuple(r)[1:6] for r in current.execute('PRAGMA table_info("' + name + '")')]
                    b = [tuple(r)[1:6] for r in src.execute('PRAGMA table_info("' + name + '")')]
                    if a != b:
                        raise ValueError("Backup table mismatch")
            self.backup()
            with open_db(self.db_path) as dst:
                src.backup(dst)
        self.recover()
        # A restore must never revive stale authority or bypass request budgets.
        self.set_setting("mode", "STOPPED")
        for key, value in (("telegram_pending_reply", None), ("telegram_autostart", False),
                           ("telegram_owner_verified_at", None), ("telegram_bot_verified_at", None)):
            self.set_setting(key, value)
        with open_db(self.db_path) as db:
            db.execute("UPDATE work_items SET approved_until=0,approval_digest=''")
            db.execute("DELETE FROM connections")
            db.execute("UPDATE grants_used SET calls=100")
            record(db, "BACKUP_RESTORED_AUTHORITY_REVOKED", "local")
