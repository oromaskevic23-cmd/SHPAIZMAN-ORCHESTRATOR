from __future__ import annotations

import json
import os
import platform
from pathlib import Path
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import tempfile

from .legacy import open_db
from .resources import memory, process_metrics


def fixed_system_query():
    if os.name != "nt":
        return {"status": "BLOCKED", "reason": "Not a Windows machine"}
    shell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    # Fixed read-only command. No user, task, config or model text is interpolated.
    command = ("$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new(); "
               "@{cpu=@(Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors); "
               "os=Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,OSArchitecture; "
               "gpu=@(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,DriverDate)} | ConvertTo-Json -Depth 4 -Compress")
    try:
        p = subprocess.run([str(shell), "-NoProfile", "-NonInteractive", "-Command", command],
                           capture_output=True, timeout=15, check=True, creationflags=0x08000000)
        return {"status": "PASS", "data": json.loads(p.stdout.decode("utf-8-sig"))}
    except (OSError, subprocess.SubprocessError, ValueError, UnicodeError):
        return {"status": "BLOCKED", "reason": "Windows CIM diagnostics unavailable"}


def gpu_query():
    if os.name != "nt":
        return {"status": "BLOCKED", "reason": "Target NVIDIA GPU not available in this environment"}
    candidates = [Path(os.environ.get("SystemRoot", r"C:\Windows"))/"System32/nvidia-smi.exe",
                  Path(os.environ.get("ProgramFiles", r"C:\Program Files"))/"NVIDIA Corporation/NVSMI/nvidia-smi.exe"]
    executable = next((p for p in candidates if p.is_file()), None)
    if not executable:
        return {"status": "BLOCKED", "reason": "nvidia-smi not found; core does not require GPU"}
    try:
        p = subprocess.run([str(executable), "--query-gpu=name,memory.total,memory.used,utilization.gpu,driver_version", "--format=csv,noheader,nounits"],
                           capture_output=True, timeout=10, check=True, creationflags=0x08000000)
        return {"status": "PASS", "columns": ["name", "vram_total_mib", "vram_used_mib", "gpu_percent", "driver"],
                "rows": [r.split(", ") for r in p.stdout.decode("utf-8", errors="replace").strip().splitlines()],
                "cuda_compute": "NOT_VERIFIED: nvidia-smi is not a CUDA computation test"}
    except (OSError, subprocess.SubprocessError):
        return {"status": "BLOCKED", "reason": "NVIDIA query failed; optional LOCAL_AI remains disabled"}


def network_query():
    # TLS reachability is separate from an authenticated platform connection.
    hosts = ["uapi.albato.com", "bot.jaicp.com", "api.tomoru.ru", "notify.twin24.ai", "api.giga.chat",
             "rest-assistant.api.cloud.yandex.net", "app.nodul.ru", "www.bitrix24.ru", "mts.ai",
             "foundation-models.api.cloud.ru", "api.telegram.org"]
    result = {}
    for host in hosts:
        try:
            with socket.create_connection((host, 443), timeout=2) as raw:
                with ssl.create_default_context().wrap_socket(raw, server_hostname=host):
                    result[host] = "TLS_REACHABLE_ONLY"
        except (OSError, ssl.SSLError):
            result[host] = "BLOCKED"
    return result


def diagnose(app, network=False):
    m = memory()
    disk = shutil.disk_usage(app.store.root)
    try:
        with tempfile.TemporaryFile(dir=app.store.root) as f:
            f.write(b"SHPAIZMAN")
            f.flush()
        writable = "PASS"
    except OSError:
        writable = "FAIL"
    with open_db(app.store.db_path) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    try:
        import tkinter
        tk_status = "PASS: import available; display smoke test is separate"
    except ImportError:
        tk_status = "FAIL"
    system = fixed_system_query()
    telegram = {"status": "BLOCKED", "configuration": "NOT_CONFIGURED",
                "bot_verified_at": app.store.get_setting("telegram_bot_verified_at"),
                "owner_verified_at": app.store.get_setting("telegram_owner_verified_at")}
    try:
        from .telegram import validate_config
        from .security import Blocked
        config = app.vault.load("telegram")
        if config:
            validate_config(config)
            telegram["configuration"] = "VALID_FORMAT"
            telegram["status"] = "PASS" if telegram["bot_verified_at"] and telegram["owner_verified_at"] else "BLOCKED"
        telegram["note"] = "PASS records past real bot/owner checks; it does not prove the bridge is currently online"
    except (Blocked, OSError, ValueError):
        telegram["configuration"] = "INVALID_OR_LOCKED"
    return {"schema": "shpaizman_diagnostics_v1", "environment": platform.platform(),
            "WINDOWS": {"status": "PASS" if os.name == "nt" and struct.calcsize("P")==8 and sys.getwindowsversion().major >= 10 else "BLOCKED",
                        "note": "Target Windows 10/11 x64; server CI does not establish target-PC acceptance", "system": system},
            "CPU": {"logical_threads": os.cpu_count(), "name_fallback": platform.processor()},
            "RAM": {"status": "PASS" if m["available"] is not None and m["available"] >= 2*1024**3 else "BLOCKED", **m},
            "DISK": {"free_bytes": disk.free, "write": writable, "status": "PASS" if disk.free>=512*1024**2 and writable=="PASS" else "FAIL"},
            "GPU": gpu_query(), "PYTHON": {"version": platform.python_version(), "bits": struct.calcsize("P")*8, "tkinter": tk_status},
            "DATABASE": {"status": "PASS" if integrity=="ok" else "FAIL", "integrity": integrity},
            "AGENTS": app.statuses(), "PLATFORMS": {r["platform"]: r["connection"] for r in app.statuses()},
            "NETWORK": network_query() if network else {"status": "BLOCKED", "reason": "Network probe not requested"},
            "TELEGRAM": telegram,
            "PROCESS": process_metrics(), "LOCAL_AI": {"model": app.store.get_setting("ollama_model"),
            "status": "CONFIGURED" if app.store.get_setting("ollama_model") else "NOT_CONFIGURED",
            "live_check": "CHECK_AI.cmd", "cuda": "NOT_VERIFIED"}}
