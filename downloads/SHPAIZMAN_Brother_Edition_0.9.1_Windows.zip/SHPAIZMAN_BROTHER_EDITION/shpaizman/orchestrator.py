from __future__ import annotations

import json
import multiprocessing as mp
import threading
import time

from . import ai_draft
from .registry import discover, route
from .resources import ResourceManager, process_metrics
from .security import Blocked, InstanceLock, RemoteFailure, Vault, validate_grant
from .store import Store


def run_worker(sender, task, config):
    """Only built-in capabilities; user/AI strings are data, never executable code."""
    start = time.monotonic()
    try:
        agent = route(task["platform"])
        payload = json.loads(task["payload"])
        if task["remote"]:
            connector = agent.connector(config)
            if task["operation"] not in connector.operations:
                raise Blocked("Agent capability denied")
            validate_grant(config, task["operation"])
            result = connector.execute(task["operation"], payload)
            state = "SUCCEEDED_REMOTE"
        elif task["operation"] == ai_draft.OPERATION:
            result = ai_draft.generate(agent, payload)
            state = "SUCCEEDED_LOCAL"
        else:
            result = agent.execute_local(task["operation"], payload)
            agent.verify(task["operation"], payload, result)
            state = "SUCCEEDED_LOCAL"
        result["worker_metrics"] = process_metrics()
        result["elapsed_ms"] = round((time.monotonic()-start)*1000)
        if len(json.dumps(result, ensure_ascii=False).encode()) > 65000:
            raise ValueError("Result too large")
        sender.send({"state": state, "result": result})
    except Blocked as e:
        sender.send({"state": "BLOCKED", "result": {"reason": str(e)[:300]}})
    except RemoteFailure as e:
        sender.send({"state": "FAILED", "retryable": e.retryable, "result": {"reason": str(e)}})
    except BaseException as e:
        # Exception messages can contain credentials or client text; retain only class.
        sender.send({"state": "FAILED", "result": {"error_type": type(e).__name__}})
    finally:
        sender.close()


class Orchestrator:
    def __init__(self, root, *, vault=None, resource_manager=None, worker_target=run_worker):
        self.lock = InstanceLock(root / "application.lock")
        try:
            self.store = Store(root)
            self.vault = vault or Vault(root)
            self.agents = discover()
            self.resources = resource_manager or ResourceManager(root)
            self.store.recover()
            self.mode = "STOPPED"
            self.store.set_setting("mode", self.mode)
            self.reason = "Press START to process queued work"
            self.active = {}
            self.ctx = mp.get_context("spawn")
            self.worker_target = worker_target
            self.guard = threading.RLock()
            self.shutdown = threading.Event()
            self.thread = threading.Thread(target=self._loop, name="SHPAIZMAN-Scheduler", daemon=True)
            self.thread.start()
        except BaseException:
            self.lock.close()
            raise

    def submit(self, specialization, operation, payload, timeout=30):
        agent = route(specialization)
        if operation == ai_draft.OPERATION:
            if not isinstance(payload, dict) or set(payload) != {"prompt"}:
                raise ValueError("AI task requires a prompt.")
            data = ai_draft.prepare(self.store.get_setting("ollama_model"), payload["prompt"])
            return self.store.enqueue_task(agent.platform, operation, data, remote=False, timeout=120)
        remote = operation != agent.operation
        if remote and operation not in agent.connector.operations:
            raise Blocked(agent.connector.blocked_reason or "Operation is not a registered capability")
        # Validate local data before queue insertion, with no external execution.
        if not remote:
            agent.execute_local(operation, payload)
        return self.store.enqueue_task(agent.platform, operation, payload, remote, timeout)

    def _mode(self, mode):
        self.mode = mode
        self.store.set_setting("mode", mode)

    def start(self):
        with self.guard:
            if self.shutdown.is_set():
                raise Blocked("Application is shutting down")
            self._mode("RUNNING")
            self.reason = "Queue processing enabled"

    def pause(self):
        with self.guard:
            self._mode("PAUSED")
            self.reason = "No new work; active jobs may finish"

    def _terminate(self, job, state):
        active = self.active.pop(job, None)
        if active:
            proc, receiver, task, config, started = active
            if proc.is_alive():
                proc.terminate()
            proc.join(1)
            if proc.is_alive():
                proc.kill()
                proc.join(1)
            receiver.close()
            proc.close()
            if task["remote"]:
                self.store.mark_connection(task["platform"], config, "ERROR", {"reason": state})
        self.store.transition(job, state, {"reason": state, "remote_effects_may_be_unknown": bool(active and active[2]["remote"])})

    def cancel(self, job):
        with self.guard:
            task = self.store.task(job)
            if not task:
                return False
            if job in self.active:
                self._terminate(job, "CANCELLED")
                return True
            return self.store.transition(job, "CANCELLED", {"reason": "Owner cancelled"})

    def stop(self):
        with self.guard:
            self._mode("STOPPED")
            self.reason = "Emergency stop: no new execution"
            for job in list(self.active):
                self._terminate(job, "CANCELLED")
            for task in self.store.tasks(5000):
                if task["state"] in {"QUEUED", "RETRY_WAIT"}:
                    self.store.transition(task["id"], "CANCELLED", {"reason": "Global stop"})

    def enable_agent(self, platform, enabled):
        agent = route(platform)
        with self.guard:
            self.store.enable_agent(agent.platform, enabled)
            if not enabled:
                for job, active in list(self.active.items()):
                    if active[2]["platform"] == agent.platform:
                        self._terminate(job, "CANCELLED")

    def configure(self, platform, config):
        route(platform)
        with self.guard:
            if any(v[2]["platform"] == platform for v in self.active.values()):
                raise Blocked("Stop the agent before changing its configuration")
            self.vault.save(platform, config)
            self.store.mark_connection(platform, config, "NOT_CONNECTED", {})
            from .legacy import open_db, record
            with open_db(self.store.db_path) as db:
                db.execute("UPDATE work_items SET approved_until=0,approval_digest='' WHERE platform=? AND remote=1", (platform,))
                record(db, "CONFIG_CHANGED_APPROVALS_REVOKED", platform)
            # Required after restore, explicitly reviewed separately for each platform.
            self.store.set_setting("configured_after_restore_" + platform, True)

    def _authorize(self, task):
        agent = self.agents[task["platform"]]
        config = self.vault.load(agent.platform)
        agent.connector(config).validate()
        if self.store.get_setting("restore_network_lock", False) and not self.store.get_setting("configured_after_restore_" + agent.platform, False):
            raise Blocked("Reconfigure this platform after backup restore")
        if task["approved_until"] < time.time() or task["approval_digest"] != task["digest"]:
            raise Blocked("Approve this exact task locally in CRM; approval expires in 10 minutes")
        self.store.reserve_request(agent.platform, task["operation"], config)
        return config

    def _poll(self):
        for job, active in list(self.active.items()):
            proc, receiver, task, config, started = active
            if time.monotonic()-started >= task["timeout"]:
                self._terminate(job, "TIMED_OUT")
                continue
            if receiver.poll():
                try:
                    output = receiver.recv()
                except (EOFError, OSError):
                    output = {"state": "FAILED", "result": {"reason": "Worker died without a result"}}
                proc.join(1)
                if proc.is_alive():
                    proc.terminate()
                    proc.join(1)
                receiver.close()
                proc.close()
                del self.active[job]
                state, result = output["state"], output["result"]
                if state == "SUCCEEDED_REMOTE":
                    receipt = result.get("receipt", {})
                    if receipt.get("transport") != "REAL_HTTPS" or receipt.get("http_status") != 200:
                        state, result = "FAILED", {"reason": "Missing real transport proof"}
                    else:
                        self.store.mark_connection(task["platform"], config, "CONNECTED_VERIFIED", receipt)
                elif task["remote"]:
                    self.store.mark_connection(task["platform"], config, "ERROR", {"reason": result.get("reason", "FAILED")})
                # Only read-only operations may retry. Mutating operations are never replayed.
                if output.get("retryable") and not self.agents[task["platform"]].connector.mutates and task["attempts"] < 3:
                    self.store.transition(job, "RETRY_WAIT", result, time.time() + 2**task["attempts"])
                else:
                    self.store.transition(job, state, result)
                self.store.maintain()
            elif not proc.is_alive():
                self._terminate(job, "FAILED")

    def _loop(self):
        while not self.shutdown.wait(0.1):
            try:
                with self.guard:
                    self._poll()
                    if self.mode != "RUNNING" or len(self.active) >= 2:
                        continue
                    admitted, self.reason = self.resources.admit([a[0].pid for a in self.active.values()])
                    if not admitted:
                        continue
                    task = self.store.claim(tuple(a[2]["platform"] for a in self.active.values()))
                    if not task:
                        continue
                    try:
                        config = self._authorize(task) if task["remote"] else {}
                        receiver, sender = self.ctx.Pipe(duplex=False)
                        proc = self.ctx.Process(target=self.worker_target, args=(sender, task, config), name=task["platform"])
                        proc.start()
                        sender.close()
                        self.active[task["id"]] = (proc, receiver, task, config, time.monotonic())
                    except Blocked as e:
                        self.store.transition(task["id"], "BLOCKED", {"reason": str(e)[:300]})
                    except Exception as e:
                        self.store.transition(task["id"], "FAILED", {"error_type": type(e).__name__})
            except Exception:
                # Storage/scheduler failure must stop all dispatch, not silently spin.
                with self.guard:
                    self.mode = "ERROR"
                    self.reason = "Scheduler/storage error; diagnostics required"
                    for job in list(self.active):
                        try:
                            self._terminate(job, "FAILED")
                        except Exception:
                            pass

    def statuses(self):
        with self.guard:
            rows = []
            for agent in self.agents.values():
                configured, connection = False, "NOT_CONNECTED"
                try:
                    config = self.vault.load(agent.platform)
                    configured = bool(config)
                    if agent.connector.blocked_reason:
                        connection = "BLOCKED"
                    elif config:
                        agent.connector(config).validate()
                        permitted = [op for op in agent.connector.operations if op in config.get("free_access", {}).get("operations", [])]
                        if not permitted:
                            raise Blocked("No free operations configured")
                        validate_grant(config, permitted[0])
                        connection = self.store.connection(agent.platform, config)
                except (ValueError, Blocked, OSError):
                    connection = "BLOCKED"
                enabled = self.store.agent_enabled(agent.platform)
                local = "READY_LOCAL" if enabled else "OFFLINE"
                if any(a[2]["platform"] == agent.platform for a in self.active.values()):
                    local = "RUNNING"
                rows.append({"id": agent.id, "platform": agent.platform, "profession": agent.profession,
                             "module": local, "connection": connection, "configured": configured,
                             "external_operations": list(agent.connector.operations),
                             "blocker": agent.connector.blocked_reason})
            return rows

    def restore(self, path):
        with self.guard:
            if self.active or self.mode == "RUNNING":
                raise Blocked("STOP before restore")
            self.store.restore(path)
            self.store.set_setting("restore_network_lock", True)
            for platform in self.agents:
                self.store.set_setting("configured_after_restore_" + platform, False)
            self.mode = "STOPPED"

    def close(self):
        if self.shutdown.is_set():
            return
        self.shutdown.set()
        self.thread.join(3)
        with self.guard:
            # Preserve pending work on orderly close; interrupt active tasks for review.
            for job in list(self.active):
                self._terminate(job, "INTERRUPTED")
            self._mode("STOPPED")
            self.store.maintain()
        self.lock.close()
