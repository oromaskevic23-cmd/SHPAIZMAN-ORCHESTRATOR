"""Local secrets and ownership boundary; no remote shell or plaintext vault."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import re
import time


class Blocked(RuntimeError):
    """A policy/availability denial safe to show without secret-bearing URLs."""


class RemoteFailure(RuntimeError):
    def __init__(self, code: str, retryable: bool = False):
        super().__init__(code)
        self.retryable = retryable


def private_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name != "nt":
        path.chmod(0o700)


def atomic_json(path: Path, data: dict) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    if os.name != "nt":
        temp.chmod(0o600)
    temp.replace(path)


def dpapi(data: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise Blocked("Secret storage requires Windows DPAPI; no plaintext fallback")

    class Blob(ctypes.Structure):
        _fields_ = [("length", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data)
    inp = Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    out = Blob()
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                   ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    fn.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    # CRYPTPROTECT_UI_FORBIDDEN; current Windows user, never LOCAL_MACHINE.
    if not fn(ctypes.byref(inp), None, None, None, None, 1, ctypes.byref(out)):
        raise Blocked("Windows could not unlock/protect this user's secrets")
    try:
        return ctypes.string_at(out.data, out.length)
    finally:
        kernel.LocalFree(out.data)


class Vault:
    def __init__(self, root: Path):
        self.root = root / "secrets"
        private_directory(self.root)

    def _path(self, name: str) -> Path:
        if name not in {"albato", "aimylogic", "tomoru", "twin", "gigachat", "yandex",
                        "nodul", "bitrix24", "mws", "cloudru", "telegram", "local_ai"}:
            raise ValueError("Unknown secret slot")
        return self.root / (name + ".dpapi")

    def load(self, name: str) -> dict:
        p = self._path(name)
        if not p.exists():
            return {}
        if p.stat().st_size > 65536:
            raise Blocked("Invalid secret file size")
        value = json.loads(dpapi(p.read_bytes(), decrypt=True))
        if not isinstance(value, dict):
            raise Blocked("Invalid secret file")
        return value

    def save(self, name: str, value: dict) -> None:
        if not isinstance(value, dict):
            raise ValueError("Configuration must be a JSON object")
        encoded = json.dumps(value, ensure_ascii=False).encode()
        if len(encoded) > 16000:
            raise ValueError("Configuration too large")
        p = self._path(name)
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(dpapi(encoded))
        tmp.replace(p)


def validate_grant(config: dict, operation: str) -> None:
    """An expiring, locally reviewed zero-cost grant, never inferred from a key."""
    grant = config.get("free_access", {})
    if not isinstance(grant, dict) or grant.get("owner_confirmed") is not True:
        raise Blocked("FREE_ONLY: local owner has not confirmed free API access")
    if grant.get("billing_disabled") is not True:
        raise Blocked("FREE_ONLY: provider billing/overage must be disabled")
    if operation not in grant.get("operations", []):
        raise Blocked("Operation is outside the free-access grant")
    expires = grant.get("expires_at", 0)
    if type(expires) not in (int, float) or not time.time() < expires <= time.time() + 31 * 86400:
        raise Blocked("Free-access evidence expired or exceeds 31 days")
    if not isinstance(grant.get("evidence"), str) or not 10 <= len(grant["evidence"]) <= 1500:
        raise Blocked("Record the provider's zero-cost evidence locally")
    cap = grant.get("max_requests", 0)
    if type(cap) is not int or not 1 <= cap <= 100:
        raise Blocked("A hard request allowance of 1..100 is required")


def safe_token(config: dict, key: str = "token") -> str:
    token = config.get(key)
    if not isinstance(token, str) or not 8 <= len(token) <= 8000 or re.search(r"[\s\x00-\x1f]", token):
        raise Blocked("Missing or malformed credential")
    return token


class InstanceLock:
    """OS lock survives races and is released by the OS on process death."""
    def __init__(self, path: Path):
        private_directory(path.parent)
        self.handle = path.open("a+b")
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # Windows enforces byte-range locks on reads as well as writes.
            # Initialize the marker only after this instance owns that range.
            if os.fstat(self.handle.fileno()).st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
        except OSError:
            self.handle.close()
            raise Blocked("SHPAIZMAN is already using this data directory") from None

    def close(self):
        if not self.handle.closed:
            self.handle.close()
