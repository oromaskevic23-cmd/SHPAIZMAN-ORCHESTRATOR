from dataclasses import dataclass
import hashlib
from ..store import canonical


def text(value, name, limit=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(name + " must be a nonempty bounded string")
    return value.strip()


def items(value, name, limit=100):
    if not isinstance(value, list) or not 1 <= len(value) <= limit:
        raise ValueError(name + " must be a nonempty bounded array")
    return value


def fields(payload, required, optional=()):
    if not isinstance(payload, dict) or set(payload) - set(required) - set(optional) or not set(required) <= set(payload):
        raise ValueError("Task fields mismatch; required: " + ", ".join(required))


@dataclass(frozen=True)
class Agent:
    id: str
    platform: str
    profession: str
    operation: str
    local_handler: object
    connector: type
    example: dict

    def execute_local(self, operation, payload):
        if operation != self.operation:
            raise ValueError("Agent capability denied")
        data = self.local_handler(payload)
        return {"agent_id": self.id, "platform": self.platform, "operation": operation,
                "mode": "LOCAL_ALGORITHM", "external_effects": False,
                "input_sha256": hashlib.sha256(canonical(payload).encode()).hexdigest(), "data": data}

    def verify(self, operation, payload, result):
        if not isinstance(result, dict) or result.get("mode") != "LOCAL_ALGORITHM":
            raise ValueError("Local result contract mismatch")
        expected = hashlib.sha256(canonical(payload).encode()).hexdigest()
        if result.get("input_sha256") != expected or result.get("agent_id") != self.id or result.get("operation") != operation or not isinstance(result.get("data"), dict):
            raise ValueError("Result does not match task")
