from decimal import Decimal, InvalidOperation
from .base import Agent, fields, items, text
from ..connectors.cloudru import CloudRuConnector


def filter_zero_cost_models(p):
    fields(p, ("catalog",))
    selected, rejected = [], []
    for row in items(p["catalog"], "catalog", 100):
        fields(row, ("id", "input_rub_per_million", "output_rub_per_million"))
        name = text(row["id"], "model id", 200)
        try:
            prices = [Decimal(str(row[k])) for k in ("input_rub_per_million", "output_rub_per_million")]
            if any(not x.is_finite() or x < 0 for x in prices):
                raise ValueError("Invalid price")
        except InvalidOperation:
            raise ValueError("Invalid price") from None
        (selected if all(x == 0 for x in prices) else rejected).append(name)
    return {"zero_price_candidates_from_input": selected, "excluded": rejected,
            "provider_entitlement_verified": False, "inference_enabled": False}


AGENT = Agent("AGENT-10", "cloudru", "Cloud AI Engineer", "filter_zero_cost_models", filter_zero_cost_models, CloudRuConnector,
              {"catalog": [{"id": "example-free", "input_rub_per_million": "0", "output_rub_per_million": "0"},
                           {"id": "example-paid", "input_rub_per_million": "1", "output_rub_per_million": "2"}]})
