from .base import Agent, fields, items, text
from ..connectors.nodul import NodulConnector


def validate_workflow(p):
    fields(p, ("nodes", "edges"))
    nodes = [text(n, "node", 80) for n in items(p["nodes"], "nodes")]
    if len(set(nodes)) != len(nodes) or not isinstance(p["edges"], list) or len(p["edges"]) > 200:
        raise ValueError("Duplicate nodes or too many edges")
    degree, outgoing = dict.fromkeys(nodes, 0), {n: [] for n in nodes}
    for edge in p["edges"]:
        if not isinstance(edge, list) or len(edge) != 2 or any(n not in degree for n in edge):
            raise ValueError("Unknown edge")
        a, b = edge
        degree[b] += 1
        outgoing[a].append(b)
    queue = [n for n in nodes if degree[n] == 0]
    order = []
    while queue:
        n = queue.pop(0)
        order.append(n)
        for target in outgoing[n]:
            degree[target] -= 1
            if not degree[target]:
                queue.append(target)
    if len(order) != len(nodes):
        raise ValueError("Workflow cycle detected")
    return {"execution_order": order, "edge_count": len(p["edges"]), "deployed": False}


AGENT = Agent("AGENT-07", "nodul", "Workflow Engineer", "validate_workflow", validate_workflow, NodulConnector,
              {"nodes": ["input", "transform", "response"], "edges": [["input", "transform"], ["transform", "response"]]})
