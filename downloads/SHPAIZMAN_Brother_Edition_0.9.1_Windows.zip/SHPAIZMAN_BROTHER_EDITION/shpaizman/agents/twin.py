from .base import Agent, fields, items, text
from ..connectors.twin import TwinConnector


def plan_delivery(p):
    fields(p, ("message", "channels", "available"))
    message = text(p["message"], "message", 2000)
    channels, available = items(p["channels"], "channels", 8), items(p["available"], "available", 8)
    permitted = {"EMAIL", "SMS", "PUSH", "CHAT", "TELEGRAM", "VKONTAKTE"}
    if len(set(channels)) != len(channels) or not set(channels + available) <= permitted:
        raise ValueError("Unknown or duplicate channel")
    route = [c for c in channels if c in available]
    if not route:
        raise ValueError("No available delivery route")
    return {"primary": route[0], "fallback": route[1:], "characters": len(message), "sent": False}


AGENT = Agent("AGENT-04", "twin", "Communications Engineer", "plan_delivery", plan_delivery, TwinConnector,
              {"message": "Example", "channels": ["CHAT", "EMAIL"], "available": ["EMAIL"]})
