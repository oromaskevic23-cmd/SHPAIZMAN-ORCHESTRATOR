from .base import Agent, fields, text
from ..connectors.albato import AlbatoConnector


def map_fields(p):
    fields(p, ("source", "mapping"))
    if not isinstance(p["source"], dict) or not isinstance(p["mapping"], dict) or not 1 <= len(p["mapping"]) <= 50:
        raise ValueError("source/mapping must be objects")
    mapped = {}
    for target, source in p["mapping"].items():
        text(target, "target", 100)
        text(source, "source field", 100)
        if source not in p["source"]:
            raise ValueError("Missing source field")
        mapped[target] = p["source"][source]
    return {"mapped_record": mapped, "fields_mapped": len(mapped)}


AGENT = Agent("AGENT-01", "albato", "Integration Engineer", "map_fields", map_fields, AlbatoConnector,
              {"source": {"customer": "Example"}, "mapping": {"NAME": "customer"}})
