from .base import Agent, fields, items, text
from ..connectors.tomoru import TomoruConnector


def validate_voice_script(p):
    fields(p, ("steps", "max_seconds"))
    steps = items(p["steps"], "steps", 20)
    if type(p["max_seconds"]) is not int or not 10 <= p["max_seconds"] <= 600:
        raise ValueError("max_seconds outside 10..600")
    budget, ids = 0, set()
    for s in steps:
        fields(s, ("id", "say", "listen_seconds"))
        sid = text(s["id"], "step id", 80)
        text(s["say"], "say", 500)
        if sid in ids or type(s["listen_seconds"]) is not int or not 1 <= s["listen_seconds"] <= 60:
            raise ValueError("Duplicate step or invalid listen timeout")
        ids.add(sid)
        budget += s["listen_seconds"]
    if budget >= p["max_seconds"]:
        raise ValueError("Listening budget leaves no time for speech")
    return {"validated_steps": len(steps), "listening_budget_seconds": budget,
            "speech_budget_seconds": p["max_seconds"] - budget, "call_initiated": False}


AGENT = Agent("AGENT-03", "tomoru", "Voice Automation Engineer", "validate_voice_script", validate_voice_script, TomoruConnector,
              {"steps": [{"id": "welcome", "say": "Добрый день", "listen_seconds": 5}], "max_seconds": 60})
