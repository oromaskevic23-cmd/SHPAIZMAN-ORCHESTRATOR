import re
from .base import Agent, fields, text
from ..connectors.yandex import YandexConnector


def build_model_request(p):
    fields(p, ("folder_id", "model", "text", "max_tokens"))
    for key in ("folder_id", "model"):
        if not isinstance(p[key], str) or not re.fullmatch(r"[A-Za-z0-9_-]{3,80}", p[key]):
            raise ValueError("Invalid model/folder identifier")
    if type(p["max_tokens"]) is not int or not 1 <= p["max_tokens"] <= 512:
        raise ValueError("max_tokens must be 1..512")
    return {"request": {"modelUri": "gpt://"+p["folder_id"]+"/"+p["model"]+"/latest",
                        "completionOptions": {"stream": False, "temperature": 0.2, "maxTokens": str(p["max_tokens"])},
                        "messages": [{"role": "user", "text": text(p["text"], "text")}]}, "submitted": False}


AGENT = Agent("AGENT-06", "yandex", "AI Model Engineer", "build_model_request", build_model_request, YandexConnector,
              {"folder_id": "example-folder", "model": "yandexgpt-lite", "text": "Example", "max_tokens": 128})
