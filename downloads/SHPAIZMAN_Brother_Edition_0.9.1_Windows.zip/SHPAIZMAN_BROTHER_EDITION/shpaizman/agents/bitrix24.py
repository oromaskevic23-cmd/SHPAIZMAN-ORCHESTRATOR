import re
from .base import Agent, fields, items, text
from ..connectors.bitrix24 import BitrixConnector


def normalize_leads(p):
    fields(p, ("leads",))
    normalized, seen = [], set()
    for row in items(p["leads"], "leads", 50):
        fields(row, ("name", "email"))
        name, email = text(row["name"], "name", 120), text(row["email"], "email", 254).lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            raise ValueError("Malformed email")
        if email not in seen:
            seen.add(email)
            normalized.append({"TITLE": name, "EMAIL": [{"VALUE": email, "VALUE_TYPE": "WORK"}]})
    return {"lead_payloads": normalized, "duplicates_removed": len(p["leads"])-len(normalized), "uploaded": False}


AGENT = Agent("AGENT-08", "bitrix24", "CRM Automation Engineer", "normalize_leads", normalize_leads, BitrixConnector,
              {"leads": [{"name": "Example", "email": "TEST@example.invalid"}]})
