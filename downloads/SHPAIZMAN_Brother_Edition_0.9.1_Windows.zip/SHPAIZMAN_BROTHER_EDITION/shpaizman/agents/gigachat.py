from .base import Agent, fields, items, text
from ..connectors.gigachat import GigaChatConnector


def prepare_language_batch(p):
    fields(p, ("texts",))
    values = [" ".join(text(t, "text", 2000).split()) for t in items(p["texts"], "texts", 50)]
    unique = list(dict.fromkeys(values))
    return {"normalized_texts": unique, "duplicates_removed": len(values)-len(unique),
            "characters": sum(map(len, unique)), "inference_performed": False}


AGENT = Agent("AGENT-05", "gigachat", "Language AI Engineer", "prepare_language_batch", prepare_language_batch, GigaChatConnector,
              {"texts": ["Hello   world", "Hello world"]})
