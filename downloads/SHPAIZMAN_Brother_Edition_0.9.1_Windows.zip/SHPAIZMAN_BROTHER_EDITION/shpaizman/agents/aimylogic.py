from .base import Agent, fields, items, text
from ..connectors.aimylogic import AimylogicConnector


def validate_dialogue(p):
    fields(p, ("start", "states"))
    states = items(p["states"], "states")
    index = {}
    for s in states:
        fields(s, ("id", "reply", "next"))
        sid = text(s["id"], "state id", 80)
        text(s["reply"], "reply")
        if sid in index or not isinstance(s["next"], list):
            raise ValueError("Duplicate state or invalid transitions")
        index[sid] = s
    if p["start"] not in index or any(n not in index for s in states for n in s["next"]):
        raise ValueError("Unknown state reference")
    seen, todo = set(), [p["start"]]
    while todo:
        n = todo.pop()
        if n not in seen:
            seen.add(n)
            todo.extend(index[n]["next"])
    terminals = [s["id"] for s in states if not s["next"]]
    if len(seen) != len(index) or not terminals:
        raise ValueError("Unreachable state or missing terminal")
    # Every reachable state must be able to finish, including cycles.
    finish = set(terminals)
    while True:
        expanded = finish | {s["id"] for s in states if any(n in finish for n in s["next"])}
        if expanded == finish:
            break
        finish = expanded
    if finish != seen:
        raise ValueError("Dialogue contains a nonterminating region")
    return {"states": len(index), "terminal_states": terminals, "reachable": sorted(seen), "valid": True}


AGENT = Agent("AGENT-02", "aimylogic", "Conversational AI Engineer", "validate_dialogue", validate_dialogue, AimylogicConnector,
              {"start": "hello", "states": [{"id": "hello", "reply": "Hello", "next": ["end"]}, {"id": "end", "reply": "Bye", "next": []}]})
