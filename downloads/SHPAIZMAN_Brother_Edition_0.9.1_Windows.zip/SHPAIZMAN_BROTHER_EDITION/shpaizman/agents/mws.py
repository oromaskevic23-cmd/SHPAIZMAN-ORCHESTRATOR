from .base import Agent, fields, items, text
from ..connectors.mws import MWSConnector


def validate_agent_policy(p):
    fields(p, ("name", "capabilities", "approval_required"))
    name = text(p["name"], "name", 100)
    caps = items(p["capabilities"], "capabilities", 10)
    allowed = {"knowledge.read", "document.classify", "draft.create", "result.verify"}
    if not set(caps) <= allowed or len(set(caps)) != len(caps) or p["approval_required"] is not True:
        raise ValueError("Policy exceeds the least-privilege contract")
    return {"name": name, "capabilities": sorted(caps), "default": "DENY", "approval_required": True, "deployed": False}


AGENT = Agent("AGENT-09", "mws", "Enterprise AI Engineer", "validate_agent_policy", validate_agent_policy, MWSConnector,
              {"name": "Knowledge helper", "capabilities": ["knowledge.read", "draft.create"], "approval_required": True})
