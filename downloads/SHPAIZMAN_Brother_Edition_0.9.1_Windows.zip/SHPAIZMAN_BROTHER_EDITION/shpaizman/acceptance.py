"""Run one real Ollama job through owner command handling and the persistent queue."""
import argparse
import hashlib
import json
import secrets
import tempfile
import time
from pathlib import Path

from .ai_draft import MODELS
from .orchestrator import Orchestrator
from .telegram import TelegramController


def verify(root, model):
    nonce = "SH-" + secrets.token_hex(4).upper()
    owner = 10001
    sequence = 0
    app = Orchestrator(Path(root))
    controller = TelegramController(app, owner)

    def command(text):
        nonlocal sequence
        sequence += 1
        return controller.handle({"update_id": sequence, "message": {
            "date": int(time.time()), "text": text, "from": {"id": owner, "is_bot": False},
            "chat": {"type": "private", "id": owner}}})

    try:
        app.store.set_setting("ollama_model", model)
        ack = command(f"/ask bitrix24 Copy the work order ID inside the brackets exactly: [{nonce}].")
        job_id = ack.split()[-1]
        command("/resume")
        deadline = time.monotonic() + 135
        while time.monotonic() < deadline:
            task = app.store.task(job_id)
            if task and task["state"] not in {"QUEUED", "RUNNING"}:
                break
            time.sleep(0.15)
        reply = command("/result " + job_id)
        command("/stop")
        status = app.mode
    finally:
        app.close()

    reopened = Orchestrator(Path(root))
    try:
        task = reopened.store.task(job_id) or {}
        result = json.loads(task.get("result") or "{}")
        text = result.get("text", "")
        digest = hashlib.sha256(text.encode()).hexdigest() if text else None
        passed = (task.get("state") == "SUCCEEDED_LOCAL" and result.get("mode") == "LOCAL_MODEL" and
                  result.get("model") == model and nonce in text and nonce in (reply or "") and
                  digest == result.get("response_sha256") and status == reopened.mode == "STOPPED")
        return {"passed": passed, "task_state": task.get("state"), "model": model, "role": "bitrix24",
                "challenge": nonce, "model_response": text, "response_sha256": digest,
                "reopened_database": True, "stop_state": status, "telegram_transport": "not exercised",
                "error": None if passed else result.get("reason", "challenge or runtime check failed")}
    finally:
        reopened.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=MODELS, default="qwen2.5:1.5b")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="shpaizman-accept-") as folder:
        evidence = verify(folder, args.model)
    print(json.dumps(evidence, ensure_ascii=True, indent=2))
    return 0 if evidence["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
