"""Brother-only, read-only payout routing registry and evidence-first revenue ledger.

No wallet signing, payment initiation, platform scraping or payout claiming.
"""
from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import uuid

from .registry import PLATFORMS

WALLET = re.compile(r"^0x[a-fA-F0-9]{40}$")
REF = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:/_.-]{4,119}$")
CURRENCY = frozenset({"USD", "EUR", "RUB", "UAH", "USDT", "USDC", "MATIC", "POL", "ETH"})
SUPPORTED_LEDGER_SCHEMA = "shpaizman_beneficiary_ledger_v1"


class TreasuryDenied(ValueError):
    pass


@dataclass(frozen=True)
class Beneficiary:
    designation: str = "Alexander Viktorovich"
    ecosystem: str = "SHPAIZMAN_BROTHER_ONLY"
    payout_wallet: str | None = None
    wallet_network: str | None = None


def validate_destination(address: str, network: str = "polygon") -> dict:
    """Validate address *format*, never ownership, checksum or chain acceptance."""
    if not isinstance(address, str) or not WALLET.fullmatch(address):
        raise TreasuryDenied("INVALID_PUBLIC_EVM_DESTINATION_ADDRESS")
    if network not in {"polygon", "ethereum"}:
        raise TreasuryDenied("UNAPPROVED_DESTINATION_NETWORK")
    return {"network": network, "address": address,
            "ownership_verified": False, "platform_payout_support": "NOT_VERIFIED",
            "transfer_authorized": False, "wallet_secret_required": False}


class RevenueLedger:
    """Immutable SQLite events with idempotency and an append-only audit chain."""
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db = self.root / "beneficiary-ledger.sqlite3"
        with self._connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS ledger_events (
                    id TEXT PRIMARY KEY, source_platform TEXT NOT NULL,
                    event_type TEXT NOT NULL, reference TEXT NOT NULL UNIQUE,
                    amount_minor TEXT NOT NULL, currency TEXT NOT NULL,
                    beneficiary TEXT NOT NULL, evidence_sha256 TEXT NOT NULL,
                    recorded_at TEXT NOT NULL, previous_sha256 TEXT NOT NULL,
                    event_sha256 TEXT NOT NULL UNIQUE
                );
                CREATE TRIGGER IF NOT EXISTS ledger_immutable_update
                  BEFORE UPDATE ON ledger_events BEGIN SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER'); END;
                CREATE TRIGGER IF NOT EXISTS ledger_immutable_delete
                  BEFORE DELETE ON ledger_events BEGIN SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER'); END;
            """)

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.db, timeout=10)
        try:
            db.execute("PRAGMA busy_timeout=10000")
            db.execute("PRAGMA journal_mode=WAL")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def record_unverified_claim(self, *, platform: str, reference: str,
                                amount: str, currency: str, evidence: str) -> dict:
        if platform not in PLATFORMS:
            raise TreasuryDenied("UNKNOWN_AGENT_PLATFORM")
        if not isinstance(reference, str) or not REF.fullmatch(reference):
            raise TreasuryDenied("INVALID_PAYOUT_REFERENCE")
        if currency not in CURRENCY:
            raise TreasuryDenied("UNKNOWN_CURRENCY")
        if not isinstance(evidence, str) or not 12 <= len(evidence) <= 2000:
            raise TreasuryDenied("EXTERNAL_PAYOUT_EVIDENCE_REQUIRED")
        if any(term in evidence.lower() for term in ["seed phrase", "private key", "mnemonic", "secret recovery"]):
            raise TreasuryDenied("WALLET_SECRET_MUST_NOT_BE_RECORDED")
        try:
            dec = Decimal(amount)
        except (InvalidOperation, TypeError):
            raise TreasuryDenied("INVALID_AMOUNT") from None
        if not dec.is_finite() or dec <= 0 or dec.as_tuple().exponent < -8 or dec > Decimal("1000000000000"):
            raise TreasuryDenied("AMOUNT_OUT_OF_BOUNDS")
        minor = str(int(dec * 100_000_000))  # exact 8-decimal universal ledger unit, not bank cents
        evidence_sha = hashlib.sha256(evidence.encode("utf-8")).hexdigest()
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            prev = db.execute("SELECT event_sha256 FROM ledger_events ORDER BY rowid DESC LIMIT 1").fetchone()
            fields = dict(id=uuid.uuid4().hex, source_platform=platform,
                          event_type="EXTERNAL_REVENUE_CLAIM_UNVERIFIED", reference=reference,
                          amount_minor=minor, currency=currency, beneficiary="Alexander Viktorovich",
                          evidence_sha256=evidence_sha,
                          recorded_at=datetime.now(timezone.utc).isoformat(),
                          previous_sha256=prev[0] if prev else "0" * 64)
            event_sha = hashlib.sha256(json.dumps(fields, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            db.execute("INSERT INTO ledger_events VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                       (*fields.values(), event_sha))
            db.commit()
        return {"id": fields["id"], "event_sha256": event_sha,
                "status": "UNVERIFIED_EXTERNAL_CLAIM", "wallet_transfer": "NOT_ATTEMPTED"}

    def verify_chain(self) -> dict:
        prior = "0" * 64
        with self._connect() as db:
            rows = db.execute("SELECT id,source_platform,event_type,reference,amount_minor,currency,"
                              "beneficiary,evidence_sha256,recorded_at,previous_sha256,event_sha256 "
                              "FROM ledger_events ORDER BY rowid").fetchall()
        for row in rows:
            fields = dict(zip(("id", "source_platform", "event_type", "reference", "amount_minor",
                               "currency", "beneficiary", "evidence_sha256", "recorded_at",
                               "previous_sha256"), row[:-1]))
            expected = hashlib.sha256(json.dumps(fields, sort_keys=True,
                                      separators=(",", ":")).encode()).hexdigest()
            if fields["previous_sha256"] != prior or expected != row[-1]:
                raise TreasuryDenied("LEDGER_HASH_CHAIN_TAMPERED")
            prior = row[-1]
        return {"schema": SUPPORTED_LEDGER_SCHEMA, "events": len(rows),
                "head_sha256": prior, "status": "INTERNAL_CHAIN_VALID_ONLY",
                "settled_revenue": "NOT_VERIFIED", "automated_payouts": "DISABLED"}
