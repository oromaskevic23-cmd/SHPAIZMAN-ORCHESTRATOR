"""Read-only catalog and locally approved service order manager; no outbound actions."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from .business import ServiceFactory, SERVICES, STAGES, BusinessDenied


def local_root() -> Path:
    base = os.getenv("LOCALAPPDATA")
    return (Path(base) if base else Path.home() / ".local" / "share") / "SHPAIZMAN-BROTHER-EDITION"


def main(argv=None):
    parser = argparse.ArgumentParser(description="SHPAIZMAN Service Factory (offline, brother-controlled)")
    parser.add_argument("--data-dir", type=Path, default=local_root())
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("catalog", help="List service packages mapped to ten agents, no revenue claim")
    sub.add_parser("dashboard", help="Offline pipeline; cash receipts are NOT verified")
    sub.add_parser("verify", help="Validate local SQLite event chain and order state")
    create = sub.add_parser("lead", help="Record permission-based inbound or authorized prospect")
    create.add_argument("--customer-alias", required=True)
    create.add_argument("--client-reference", required=True)
    create.add_argument("--service", required=True, choices=tuple(SERVICES))
    create.add_argument("--quote-minor", type=int, required=True)
    create.add_argument("--currency", required=True, choices=("RUB", "UAH", "USD", "EUR"))
    create.add_argument("--event-key", required=True)
    create.add_argument("--contact-consent-confirmed", action="store_true")
    step = sub.add_parser("advance", help="Record the next stage after offline evidence and local approval")
    step.add_argument("--order-id", required=True)
    step.add_argument("--stage", required=True, choices=STAGES[1:])
    step.add_argument("--event-key", required=True)
    step.add_argument("--evidence-sha256", required=True)
    step.add_argument("--external-ref")
    step.add_argument("--brother-confirmed", action="store_true")
    args=parser.parse_args(argv)
    if args.command=="catalog":
        print(json.dumps({"schema":"shpaizman_service_catalog_v1","offers":SERVICES,
                          "quotes_are_negotiated":True,"revenue_verified":False},indent=2));return 0
    factory=ServiceFactory(args.data_dir)
    try:
        if args.command=="dashboard":value=factory.dashboard()
        elif args.command=="verify":value=factory.verification()
        elif args.command=="lead":
            value=factory.create_lead(customer_alias=args.customer_alias,
                client_reference=args.client_reference,service=args.service,
                quote_minor=args.quote_minor,currency=args.currency,
                event_key=args.event_key,contact_consent=args.contact_consent_confirmed)
        else:
            value=factory.advance(args.order_id,args.stage,event_key=args.event_key,
                evidence_sha256=args.evidence_sha256,external_ref=args.external_ref,
                brother_confirmed=args.brother_confirmed)
        print(json.dumps(value,indent=2,ensure_ascii=False));return 0
    except BusinessDenied as e:
        parser.exit(2,"BLOCKED: "+str(e)+"\n")

if __name__=="__main__":raise SystemExit(main())
