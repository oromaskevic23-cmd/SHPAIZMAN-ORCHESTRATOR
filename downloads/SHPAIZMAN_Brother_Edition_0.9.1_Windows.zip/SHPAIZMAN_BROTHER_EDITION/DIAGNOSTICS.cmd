@echo off
setlocal
cd /d "%~dp0"
py -3.12 run.py diagnostics
set "rc=%errorlevel%"
pause
exit /b %rc%
