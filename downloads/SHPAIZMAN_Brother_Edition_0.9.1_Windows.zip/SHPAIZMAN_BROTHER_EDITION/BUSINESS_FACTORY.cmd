@echo off
setlocal
cd /d "%~dp0"
py -3.12 -m shpaizman.business_cli catalog
set "rc=%errorlevel%"
pause
exit /b %rc%
