"""Single Tkinter CRM window; all controls invoke the real local application."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog

from . import ai_draft
from .diagnostics import diagnose
from .registry import route
from .security import Blocked
from .telegram import TelegramService, validate_config


class Desktop:
    def __init__(self, app, *, wizard=True):
        self.app, self.telegram = app, None
        self.root = tk.Tk()
        self.root.title("Шпайзман • Brother Edition 0.9.0")
        self.root.geometry("1180x780")
        self.root.minsize(960, 650)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.messages = queue.Queue()
        self.closed = False
        self.callbacks = {}
        self._style()
        header = ttk.Frame(self.root, padding=16)
        header.pack(fill="x")
        ttk.Label(header, text="SHPAIZMAN BROTHER EDITION", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Alexander Viktorovich  ·  One orchestrator  ·  Ten specialists  ·  Local CRM", style="Hint.TLabel").pack(anchor="w", pady=5)
        self.status = ttk.Label(header, text="ORCHESTRATOR STATUS: STOPPED")
        self.status.pack(anchor="w")
        toolbar = ttk.Frame(self.root, padding=(16, 0))
        toolbar.pack(fill="x")
        for label, fn in (("START", app.start), ("PAUSE", app.pause), ("STOP", app.stop), ("DIAGNOSTICS", self.diagnostics)):
            self.button(toolbar, label, fn).pack(side="left", padx=(0, 8))
        self.metrics = ttk.Label(toolbar, text="", style="Hint.TLabel")
        self.metrics.pack(side="right")
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=16, pady=12)
        self.panels = {}
        for key, title in (("agents", "TEN AGENTS"), ("platforms", "TEN PLATFORMS"), ("tasks", "TASK QUEUE"),
                           ("clients", "CLIENTS"), ("deals", "PROJECTS & DEALS"), ("income", "INCOME IN RUBLES"),
                           ("audit", "ACTIVITY LOG"), ("settings", "SETTINGS"), ("backup", "BACKUP & RESTORE")):
            p = ttk.Frame(notebook, padding=12)
            notebook.add(p, text=title)
            self.panels[key] = p
        self._agents()
        self._tasks()
        self._crm()
        self._settings()
        self._backup()
        self.audit_tree = self.table(self.panels["audit"], ("Event", "Object", "Time"))
        self.footer = ttk.Label(self.root, text="Локальные операции и CRM работают без модели. Текстовые задания используют Ollama на этом ПК.", style="Hint.TLabel", padding=(16, 0, 16, 12))
        self.footer.pack(fill="x")
        self.refresh()
        if wizard and not app.store.get_setting("setup_complete", False):
            self.root.after(150, self.wizard)
        elif app.store.get_setting("telegram_autostart", False):
            self.root.after(150, lambda: self.execute(self.start_telegram))

    def _style(self):
        self.root.configure(bg="#101828")
        s = ttk.Style(self.root)
        if "clam" in s.theme_names():
            s.theme_use("clam")
        s.configure("TFrame", background="#101828")
        s.configure("TLabel", background="#101828", foreground="#e8edf4", font=("Segoe UI", 10))
        s.configure("Title.TLabel", font=("Segoe UI", 19, "bold"), foreground="#f4f8fd")
        s.configure("Hint.TLabel", foreground="#a7bad1", font=("Segoe UI", 9))
        s.configure("TButton", padding=(10, 6))
        s.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def execute(self, fn):
        try:
            return fn()
        except Exception as e:
            # Do not display raw provider errors/URLs/tokens.
            text = str(e)[:300] if isinstance(e, (ValueError, Blocked, InvalidOperation)) else type(e).__name__ + ": операция не выполнена"
            messagebox.showerror("SHPAIZMAN", text, parent=self.root)

    def button(self, frame, label, fn):
        callback = lambda: self.execute(fn)
        self.callbacks[label] = callback
        return ttk.Button(frame, text=label, command=callback)

    def table(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        for c in columns:
            tree.heading(c, text=c)
            tree.column(c, width=145, minwidth=70)
        sy = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def fill(self, tree, rows):
        selection = tree.selection()
        tree.delete(*tree.get_children())
        for row in rows:
            tree.insert("", "end", iid=str(row[0]), values=row)
        if selection and tree.exists(selection[0]):
            tree.selection_set(selection[0])

    def selected(self, tree):
        values = tree.selection()
        if not values:
            raise ValueError("Выберите строку")
        return values[0]

    def show(self, title, value):
        window = tk.Toplevel(self.root)
        window.title(title)
        window.geometry("850x550")
        t = tk.Text(window, wrap="word", font=("Consolas", 10))
        t.pack(fill="both", expand=True)
        t.insert("1.0", value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2))
        t.configure(state="disabled")

    def _agents(self):
        p = self.panels["agents"]
        ttk.Label(p, text="READY_LOCAL — модуль работает локально. Внешнее подключение показано отдельно.").pack(anchor="w")
        self.agent_tree = self.table(p, ("Agent", "Platform", "Profession", "Local state", "Connection"))
        row = ttk.Frame(p)
        row.pack(fill="x")
        for label, enabled in (("ENABLE AGENT", True), ("STOP AGENT", False)):
            self.button(row, label, lambda e=enabled: self.app.enable_agent(route(self.selected(self.agent_tree)).platform, e)).pack(side="left", padx=4)
        self.button(row, "LOCAL SELF-CHECK × 10", self.queue_examples).pack(side="right")
        p = self.panels["platforms"]
        ttk.Label(p, text="CONNECTED_VERIFIED действует 15 минут и относится только к выполненному API-методу.").pack(anchor="w")
        self.platform_tree = self.table(p, ("Platform", "Connection", "Configured", "Operations / blocker"))
        self.button(p, "PREPARE CONNECTION CHECK", self.prepare_check).pack(anchor="w")

    def queue_examples(self):
        for agent in self.app.agents.values():
            self.app.submit(agent.platform, agent.operation, agent.example)

    def prepare_check(self):
        agent = route(self.selected(self.platform_tree))
        if not agent.connector.operations:
            raise Blocked(agent.connector.blocked_reason)
        operation = agent.connector.operations[0]
        payload = {"query": "Проверка подключения SHPAIZMAN"} if agent.platform == "aimylogic" else {}
        job = self.app.submit(agent.platform, operation, payload)
        self.show("Проверка поставлена в очередь", {"task": job, "next": "TASK QUEUE → APPROVE EXTERNAL → START", "note": "Нужны собственные учётные данные и подтверждённый бесплатный доступ."})

    def _tasks(self):
        p = self.panels["tasks"]
        row = ttk.Frame(p)
        row.pack(fill="x")
        self.task_platform = tk.StringVar(value="albato")
        platform = ttk.Combobox(row, values=list(self.app.agents), state="readonly", textvariable=self.task_platform, width=14)
        platform.pack(side="left", padx=4)
        self.task_operation = tk.StringVar()
        self.operation_combo = ttk.Combobox(row, state="readonly", textvariable=self.task_operation, width=30)
        self.operation_combo.pack(side="left", padx=4)
        self.button(row, "ADD TASK", self.add_task).pack(side="left", padx=4)
        self.payload = tk.Text(p, height=5, font=("Consolas", 10), wrap="word")
        self.payload.pack(fill="x", pady=8)
        def select(_=None):
            a = route(self.task_platform.get())
            self.operation_combo["values"] = [a.operation, ai_draft.OPERATION, *a.connector.operations]
            self.task_operation.set(a.operation)
            self.payload.delete("1.0", "end")
            self.payload.insert("1.0", json.dumps(a.example, ensure_ascii=False))
        def select_operation(_=None):
            self.payload.delete("1.0", "end")
            current = self.task_operation.get()
            agent = route(self.task_platform.get())
            if current != ai_draft.OPERATION:
                self.payload.insert("1.0", json.dumps(agent.example if current == agent.operation else {}, ensure_ascii=False))
            self.payload.focus_set()
        self.operation_combo.bind("<<ComboboxSelected>>", select_operation)
        platform.bind("<<ComboboxSelected>>", select)
        select()
        self.task_tree = self.table(p, ("ID", "Agent", "Operation", "State", "Attempts"))
        row = ttk.Frame(p)
        row.pack(fill="x")
        self.button(row, "CANCEL TASK", lambda: self.app.cancel(self.selected(self.task_tree))).pack(side="left", padx=4)
        self.button(row, "VIEW RESULT", self.view_result).pack(side="left", padx=4)
        self.button(row, "APPROVE EXTERNAL", self.approve).pack(side="left", padx=4)

    def add_task(self):
        operation = self.task_operation.get()
        text = self.payload.get("1.0", "end-1c")
        payload = {"prompt": text} if operation == ai_draft.OPERATION else json.loads(text)
        job = self.app.submit(self.task_platform.get(), operation, payload)
        self.show("Задание в очереди", f"ID: {job}\nДля обработки включите START. Результат появится в TASK QUEUE.")

    def view_result(self):
        t = self.app.store.task(self.selected(self.task_tree))
        self.show("Task result", {"id": t["id"], "state": t["state"], "result": json.loads(t["result"]) if t["result"] else None})

    def approve(self):
        t = self.app.store.task(self.selected(self.task_tree))
        if not t["remote"] or t["state"] != "QUEUED":
            raise ValueError("Нужно внешнее задание в состоянии QUEUED")
        note = (f"Платформа: {t['platform']}\nОперация: {t['operation']}\nТочные данные: {t['payload']}\n\n"
                "Разрешить это задание на 10 минут? Бесплатность доступа должна быть подтверждена в SETTINGS. "
                "Действие, отправленное площадке, может быть невозможно отменить.")
        if messagebox.askyesno("Подтверждение владельца", note, parent=self.root):
            self.app.store.approve(t["id"])

    def _crm(self):
        p = self.panels["clients"]
        row = ttk.Frame(p)
        row.pack(fill="x")
        self.button(row, "ADD CLIENT", self.add_client).pack(side="left", padx=4)
        self.button(row, "EDIT CLIENT", self.edit_client).pack(side="left", padx=4)
        self.client_tree = self.table(p, ("ID", "Name", "Note"))
        p = self.panels["deals"]
        row = ttk.Frame(p)
        row.pack(fill="x")
        self.button(row, "ADD PROJECT / DEAL", self.add_deal).pack(side="left", padx=4)
        self.button(row, "CHANGE STAGE", self.change_stage).pack(side="left", padx=4)
        self.deal_tree = self.table(p, ("ID", "Client", "Platform", "Title", "Stage", "Planned RUB"))
        ttk.Label(p, text="Перед добавлением сделки выберите клиента во вкладке CLIENTS.").pack(anchor="w")
        p = self.panels["income"]
        self.income_label = ttk.Label(p, text="0.00 RUB", style="Title.TLabel")
        self.income_label.pack(anchor="w", pady=12)
        ttk.Label(p, text="Доход по платежам, внесённым владельцем. Суммы сделок не считаются оплатой.\nБанковская сверка не подключена.").pack(anchor="w")
        self.button(p, "RECORD RECEIVED PAYMENT", self.payment).pack(anchor="w", pady=16)
        ttk.Label(p, text="Выберите сделку во вкладке PROJECTS & DEALS перед внесением платежа.").pack(anchor="w")

    def add_client(self):
        name = simpledialog.askstring("Клиент", "Имя / организация", parent=self.root)
        if name:
            self.app.store.add_client(name)

    def edit_client(self):
        cid = self.selected(self.client_tree)
        row = next(c for c in self.app.store.clients() if c["id"] == cid)
        name = simpledialog.askstring("Клиент", "Имя", initialvalue=row["name"], parent=self.root)
        if name:
            note = simpledialog.askstring("Клиент", "Заметка", initialvalue=row["note"], parent=self.root)
            if note is not None:
                self.app.store.update_client(cid, name, note)

    def add_deal(self):
        cid = self.selected(self.client_tree)
        title = simpledialog.askstring("Проект / сделка", "Название", parent=self.root)
        if not title:
            return
        platform = simpledialog.askstring("Платформа", ", ".join(self.app.agents), initialvalue="albato", parent=self.root)
        if platform is None:
            return
        amount = simpledialog.askinteger("Сумма", "Плановая сумма, целые рубли", minvalue=0, maxvalue=10**9, initialvalue=0, parent=self.root)
        if amount is not None:
            self.app.store.add_deal(cid, route(platform).platform, title, amount)

    def change_stage(self):
        stage = simpledialog.askstring("Этап сделки", "lead / qualified / in_progress / delivered / closed / lost", parent=self.root)
        if stage:
            self.app.store.set_deal_stage(self.selected(self.deal_tree), stage)

    def payment(self):
        deal = self.selected(self.deal_tree)
        amount = simpledialog.askstring("Платёж", "Получено рублей (например 1500.50)", parent=self.root)
        if amount is None:
            return
        value = Decimal(amount.replace(",", ".")) * 100
        if not value.is_finite() or value != value.to_integral_value():
            raise ValueError("Сумма должна содержать не более двух знаков после запятой")
        reference = simpledialog.askstring("Платёж", "Уникальная ссылка на квитанцию / номер документа", parent=self.root)
        if reference:
            self.app.store.record_payment(deal, int(value), reference)

    def _settings(self):
        p = self.panels["settings"]
        p.columnconfigure(1, weight=1)
        self.config_platform = tk.StringVar(value="albato")
        ttk.Label(p, text="Платформа / модуль").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Combobox(p, textvariable=self.config_platform, values=[*self.app.agents, "telegram"], state="readonly").grid(row=0, column=1, sticky="ew", pady=4)
        self.config_vars = {}
        for n, (key, label, secret) in enumerate((("token", "Token / Access token", True), ("webhook_url", "Webhook URL (если нужен)", True),
                                               ("folder_id", "Yandex folder ID", False), ("owner_id", "Telegram ID владельца", False),
                                               ("evidence", "Источник подтверждения бесплатного API", False)), start=1):
            ttk.Label(p, text=label).grid(row=n, column=0, sticky="w", pady=4)
            var = tk.StringVar()
            self.config_vars[key] = var
            ttk.Entry(p, textvariable=var, show="*" if secret else "").grid(row=n, column=1, sticky="ew", pady=4)
        self.free_confirm = tk.BooleanVar(value=False)
        self.isolated = tk.BooleanVar(value=False)
        self.auto_telegram = tk.BooleanVar(value=False)
        ttk.Checkbutton(p, text="Проверил бесплатность выбранных API-операций; billing/overage отключены у провайдера", variable=self.free_confirm).grid(row=6, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Checkbutton(p, text="Aimylogic/Nodul: изолированный тестовый сценарий без платных или сторонних действий", variable=self.isolated).grid(row=7, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Checkbutton(p, text="Запускать настроенный Telegram вместе с CRM", variable=self.auto_telegram).grid(row=8, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Label(p, text="Разрешение на бесплатный доступ: 24 часа, максимум 20 запросов.\nСохранение настройки не запускает внешние запросы. Секреты шифруются Windows DPAPI.\nНи платные облачные модели, ни подписки программа не подключает.", style="Hint.TLabel").grid(row=9, column=0, columnspan=2, sticky="w", pady=8)
        row = ttk.Frame(p)
        row.grid(row=10, column=0, columnspan=2, sticky="w", pady=6)
        self.button(row, "SAVE CONFIGURATION", self.save_config).pack(side="left", padx=4)
        self.button(row, "START TELEGRAM", self.start_telegram).pack(side="left", padx=4)
        self.button(row, "STOP TELEGRAM", self.stop_telegram).pack(side="left", padx=4)
        self.telegram_label = ttk.Label(p, text="Telegram: OFFLINE")
        self.telegram_label.grid(row=11, column=0, columnspan=2, sticky="w", pady=6)
        self.model = tk.StringVar(value=self.app.store.get_setting("ollama_model") or "")
        options = ttk.Frame(p)
        options.grid(row=12, column=0, columnspan=2, sticky="w")
        ttk.Label(options, text="Ollama на этом ПК").pack(side="left", padx=4)
        ttk.Combobox(options, textvariable=self.model, values=ai_draft.MODELS, state="readonly", width=18).pack(side="left")
        self.button(options, "SAVE MODEL", self.save_model).pack(side="left", padx=6)

    def save_model(self):
        if self.model.get() not in ai_draft.MODELS:
            raise ValueError("Выберите установленную модель.")
        self.app.store.set_setting("ollama_model", self.model.get())
        messagebox.showinfo("SHPAIZMAN", "Модель для новых заданий: " + self.model.get(), parent=self.root)

    def save_config(self):
        platform = self.config_platform.get()
        values = {k: v.get().strip() for k, v in self.config_vars.items()}
        if platform == "telegram":
            self.stop_telegram()
            config = {"token": values["token"], "owner_id": int(values["owner_id"])}
            validate_config(config)
            old = self.app.vault.load("telegram")
            self.app.vault.save("telegram", config)
            if old != config:
                for key, value in (("telegram_offset", 0), ("telegram_pending_reply", None), ("telegram_update_at", 0), ("telegram_last_authorized", -1), ("telegram_owner_verified_at", None), ("telegram_bot_verified_at", None)):
                    self.app.store.set_setting(key, value)
            self.app.store.set_setting("telegram_autostart", self.auto_telegram.get())
        else:
            agent = route(platform)
            config = {k: v for k, v in values.items() if k in {"token", "webhook_url", "folder_id"} and v}
            config.update({"isolated_test_bot": self.isolated.get(), "isolated_free_workflow": self.isolated.get()})
            config["free_access"] = {"owner_confirmed": self.free_confirm.get(), "billing_disabled": self.free_confirm.get(),
                                     "expires_at": time.time()+86400, "evidence": values["evidence"],
                                     "operations": list(agent.connector.operations), "max_requests": 20}
            if not agent.connector.blocked_reason:
                agent.connector(config).validate()
            self.app.configure(platform, config)
        for var in self.config_vars.values():
            var.set("")
        self.free_confirm.set(False)
        self.isolated.set(False)
        messagebox.showinfo("SHPAIZMAN", "Настройки сохранены локально", parent=self.root)

    def start_telegram(self):
        if self.telegram and self.telegram.thread and self.telegram.thread.is_alive():
            return
        self.telegram = TelegramService(self.app, self.app.vault.load("telegram"))
        self.telegram.start()

    def stop_telegram(self):
        if self.telegram:
            self.telegram.close()
            self.telegram = None

    def _backup(self):
        p = self.panels["backup"]
        ttk.Label(p, text="SQLite backup API • Проверка целостности • Хранятся последние 7 копий\nСоздавайте копию этой кнопкой перед изменениями и в конце работы.\nКопии содержат клиентов и задачи. Храните их только в защищённой папке.\nТокены DPAPI не включаются. После восстановления требуется повторная настройка платформ.").pack(anchor="w", pady=12)
        self.button(p, "CREATE BACKUP", lambda: self.show("Backup", str(self.app.store.backup()))).pack(anchor="w", pady=8)
        self.button(p, "RESTORE BACKUP", self.restore).pack(anchor="w", pady=8)
        self.button(p, "EXPORT TASK RESULTS", self.export_tasks).pack(anchor="w", pady=8)

    def restore(self):
        if self.telegram:
            raise Blocked("STOP TELEGRAM before restoring")
        file = filedialog.askopenfilename(parent=self.root, filetypes=[("SQLite backup", "*.sqlite3")])
        if file and messagebox.askyesno("Restore", "Заменить текущую CRM выбранной копией? Перед заменой будет сделан backup.", parent=self.root):
            self.app.restore(Path(file))

    def export_tasks(self):
        path = filedialog.asksaveasfilename(parent=self.root, defaultextension=".json", initialfile="SHPAIZMAN-task-results.json")
        if path:
            Path(path).write_text(json.dumps(self.app.store.tasks(5000), ensure_ascii=False, indent=2), encoding="utf-8")

    def diagnostics(self):
        def work():
            try:
                report = diagnose(self.app, network=True)
                self.messages.put(("Диагностика", report))
            except Exception as e:
                self.messages.put(("Диагностика", {"status": "FAIL", "error_type": type(e).__name__}))
        threading.Thread(target=work, daemon=True).start()

    def wizard(self):
        win = tk.Toplevel(self.root)
        win.title("Первичная настройка SHPAIZMAN")
        win.geometry("650x380")
        p = ttk.Frame(win, padding=20)
        p.pack(fill="both", expand=True)
        ttk.Label(p, text="Установка для Александра Викторовича", style="Title.TLabel").pack(anchor="w", pady=10)
        ttk.Label(p, text="1. Основной режим работает без GPU и AI-модели.\n2. Два рабочих процесса; SQLite хранит очередь и CRM.\n3. SETTINGS: собственные аккаунты и Telegram ID.\n4. Проверьте бесплатный доступ перед внешним API.\n5. TASK QUEUE: добавьте и подтвердите внешние задачи.\n6. START запускает очередь; STOP отменяет исполнение.\n\nПК и Windows ещё требуют фактической приёмки.").pack(anchor="w", pady=10)
        def finish():
            self.app.store.set_setting("setup_complete", True)
            win.destroy()
            if self.app.store.get_setting("telegram_autostart", False):
                self.execute(self.start_telegram)
        ttk.Button(p, text="Завершить настройку", command=finish).pack(anchor="w", pady=12)

    def refresh(self):
        if self.closed:
            return
        rows = self.app.statuses()
        self.fill(self.agent_tree, [(r["id"], r["platform"], r["profession"], r["module"], r["connection"]) for r in rows])
        self.fill(self.platform_tree, [(r["platform"], r["connection"], r["configured"], r["blocker"] or ", ".join(r["external_operations"])) for r in rows])
        tasks = self.app.store.tasks()
        self.fill(self.task_tree, [(r["id"], r["platform"], r["operation"], r["state"], r["attempts"]) for r in tasks])
        self.fill(self.client_tree, [(r["id"], r["name"], r["note"]) for r in self.app.store.clients()])
        self.fill(self.deal_tree, [(r["id"], r["client_name"], r["platform"], r["title"], r["status"], r["amount_rub"]) for r in self.app.store.deals()])
        self.fill(self.audit_tree, [(str(i), r["event"]+" / "+r["subject"], r["timestamp"]) for i,r in enumerate(self.app.store.audit())])
        n = self.app.store.summary()["income_kopecks_owner_recorded"]
        self.income_label.configure(text=f"{n//100:,}.{n%100:02d} RUB")
        with self.app.guard:
            metrics = self.app.resources.snapshot([a[0].pid for a in self.app.active.values()])
        self.metrics.configure(text=f"RAM: {metrics['rss_bytes']/1024**2:.1f} MiB  |  Workers: {len(self.app.active)}/2")
        self.status.configure(text=f"ORCHESTRATOR STATUS: {self.app.mode}  ·  {self.app.reason}")
        self.telegram_label.configure(text="Telegram: " + (self.telegram.status if self.telegram else "OFFLINE"))
        while not self.messages.empty():
            title, value = self.messages.get_nowait()
            self.show(title, value)
        self.refresh_id = self.root.after(1000, self.refresh)

    def close(self):
        try:
            self.stop_telegram()
        except Blocked as e:
            messagebox.showerror("SHPAIZMAN", str(e), parent=self.root)
            return
        self.closed = True
        self.root.after_cancel(self.refresh_id)
        self.app.close()
        self.root.destroy()

    def run(self):
        self.root.mainloop()
