"""Create a source install kit from an explicit allowlist; never include runtime data."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
PREFIXES = {"shpaizman", "scripts", "tests", "docs", "evidence", "governance"}
ROOT_FILES = {"README.md", "START_HERE_RU.txt", "run.py", "INSTALL.cmd", "START_SHPAIZMAN.cmd", "DIAGNOSTICS.cmd", "RUN_TESTS.cmd", "requirements-build.txt", ".gitignore", "BUSINESS_FACTORY.cmd", "CHECK_AI.cmd", "PAIR_TELEGRAM.cmd", "AUTHORS.md", "LICENSE"}
EXTENSIONS = {".py", ".md", ".txt", ".json", ".ps1", ".yml", ".cmd", ".log", ".png"}


def manifest(root=ROOT):
    files=[]
    for path in sorted(root.rglob("*")):
        rel=path.relative_to(root)
        if not path.is_file() or path.is_symlink() or "__pycache__" in rel.parts:
            continue
        if len(rel.parts)==1 and rel.name in ROOT_FILES or rel.parts[0] in PREFIXES and path.suffix in EXTENSIONS:
            files.append(path)
    lines=[hashlib.sha256(p.read_bytes()).hexdigest()+"  "+p.relative_to(root).as_posix() for p in files]
    (root/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return files+[root/"SHA256SUMS.txt"]


def package(output):
    files=manifest()
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p,"SHPAIZMAN_BROTHER_EDITION/"+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as z:
        bad=z.testzip()
        if bad:
            raise RuntimeError("Corrupt archive entry: "+bad)
    digest=hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix(output.suffix+".sha256").write_text(digest+"  "+output.name+"\n",encoding="utf-8")
    return {"archive":str(output),"sha256":digest,"bytes":output.stat().st_size,"files":len(files),"zip_crc":"PASS","type":"SOURCE_PYTHON_INSTALL_KIT"}


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--manifest-only",action="store_true")
    p.add_argument("--output",type=Path,default=ROOT/"artifacts/SHPAIZMAN_Brother_Edition_0.9.0_Windows.zip")
    a=p.parse_args()
    if a.manifest_only:
        print("Manifest files:",len(manifest()))
    else:
        print(json.dumps(package(a.output),indent=2))
